#!/bin/bash
# =====================================================
# Clean Git repository of ignored / trash files
# =====================================================

echo "🧹 Cleaning Git repository..."

# 1. Supprimer tous les fichiers et dossiers ignorés (selon .gitignore)
echo "➡️  Removing all ignored files and folders..."
git clean -fdX

# 2. Supprimer aussi les fichiers non versionnés (optionnel, -x inclut tout, même les fichiers non listés)
# ⚠️ Si tu veux garder certains fichiers non suivis, commente cette ligne :
git clean -fdx

# 3. Recréer les fichiers .gitkeep exclus explicitement
if [ -f "public/uploads/.gitkeep" ]; then
  echo "✅ Restoring .gitkeep in public/uploads/"
  mkdir -p public/uploads
  touch public/uploads/.gitkeep
fi

# 4. Rafraîchir l’index Git
echo "🔄 Refreshing Git index..."
git rm -r --cached .
git add .
git commit -m "Clean repository from ignored and trash files"

# 5. Résumé
echo "✨ Cleanup completed. Ignored files removed and index refreshed!"


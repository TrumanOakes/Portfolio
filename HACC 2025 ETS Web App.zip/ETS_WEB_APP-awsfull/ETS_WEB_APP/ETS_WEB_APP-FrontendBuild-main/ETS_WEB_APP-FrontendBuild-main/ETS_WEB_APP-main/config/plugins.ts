export default () => ({
  'documentation': { enabled: true },
});


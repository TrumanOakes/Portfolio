export default {
  routes: [
    // 🔹 READ all reports (public or authenticated)
    {
      method: 'GET',
      path: '/reports',
      handler: 'report.find',
      config: {
        auth: false, // ou true si tu veux restreindre aux vendors
      },
    },

    // 🔹 READ one report by ID
    {
      method: 'GET',
      path: '/reports/:id',
      handler: 'report.findOne',
      config: {
        auth: false, // ou policy si tu veux restreindre
        // Exemple si tu veux filtrer par vendor :
        // policies: [{ name: 'global::is-vendor-owner', config: { uid: 'api::report.report' } }],
      },
    },

    // 🔹 CREATE
    {
      method: 'POST',
      path: '/reports',
      handler: 'report.create',
      config: {
        //policies: [{ name: 'global::is-vendor-owner', config: { uid: 'api::report.report' } }],
      },
    },

    // 🔹 UPDATE
    {
      method: 'PUT',
      path: '/reports/:id',
      handler: 'report.update',
      config: {
        //policies: [{ name: 'global::is-vendor-owner', config: { uid: 'api::report.report' } }],
      },
    },

    // 🔹 DELETE
    {
      method: 'DELETE',
      path: '/reports/:id',
      handler: 'report.delete',
      config: {
        //policies: [{ name: 'global::is-vendor-owner', config: { uid: 'api::report.report' } }],
      },
    },
  ],
};


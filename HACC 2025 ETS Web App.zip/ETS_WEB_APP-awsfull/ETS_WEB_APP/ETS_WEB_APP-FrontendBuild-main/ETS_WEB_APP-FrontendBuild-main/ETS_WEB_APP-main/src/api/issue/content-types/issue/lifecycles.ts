const score = (lvl?: string) => (lvl === 'High' ? 3 : lvl === 'Medium' ? 2 : 1);
const daysBetween = (a: Date | string, b: Date | string) =>
  Math.max(0, Math.floor((new Date(a).getTime() - new Date(b).getTime()) / 86_400_000));

const compute = (data: any) => {
  if (!data) return;

  // hardening: never trust incoming values for computed fields
  delete data.risk_rating;
  delete data.age_days;

  const s = score(data.impact) + score(data.likelihood);
  if (Number.isFinite(s)) {
    const clamped = Math.min(6, Math.max(2, s));
    data.risk_rating = clamped;
  }
  if (data.date_first_raised) {
    data.age_days = daysBetween(new Date(), data.date_first_raised);
  }
};

export default {
  beforeCreate(event: any) {
    compute(event.params.data);
  },
  beforeUpdate(event: any) {
    compute(event.params.data);
  },
} as any;


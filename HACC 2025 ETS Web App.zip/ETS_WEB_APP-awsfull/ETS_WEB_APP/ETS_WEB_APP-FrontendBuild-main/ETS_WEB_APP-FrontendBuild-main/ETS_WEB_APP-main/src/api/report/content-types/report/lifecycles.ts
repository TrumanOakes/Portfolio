/** Extract a numeric projectId from possible payload shapes (v5 connect/set/id). */
const getProjectId = (projectField: any): number | null => {
  if (!projectField) return null;
  if (typeof projectField === 'number') return projectField;
  const id =
    projectField?.connect?.[0]?.id ??
    projectField?.set?.[0]?.id ??
    projectField?.id;
  return typeof id === 'number' ? id : null;
};

/** Normalize report_month to first day of month (UTC ISO) to avoid tz issues. */
const normalizeMonth = (month: any): string | null => {
  if (!month) return null;
  const d = new Date(month);
  if (Number.isNaN(d.getTime())) return null;
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString();
};

const ensureUniqueCombo = async (strapi: any, data: any, excludeId?: number) => {
  const projectId = getProjectId(data.project);
  const monthISO  = normalizeMonth(data.report_month);
  if (!projectId || !monthISO) return;

  const existing = await strapi.entityService.findMany('api::report.report', {
    filters: {
      project: projectId,
      report_month: monthISO,
      ...(excludeId ? { id: { $ne: excludeId } } : {}),
    },
    limit: 1,
    fields: ['id'],
  });

  if (Array.isArray(existing) && existing.length > 0) {
    throw new Error('A report already exists for this (project, report_month).');
  }
};

const lockIfPublished = async (strapi: any, result: any) => {
  if (!result) return;
  if (result.publishedAt && !result.locked) {
    await strapi.entityService.update('api::report.report', result.id, {
      data: { locked: true },
    });
  }
};

const preventUpdatesWhenLocked = async (strapi: any, params: any) => {
  // const id = params?.where?.id;
  // if (!id) return;
  // const current: any = await strapi.entityService.findOne('api::report.report', id, {
  //   fields: ['id', 'locked'],
  // });
  // if (current?.locked) {
  //   throw new Error('This report is locked and cannot be modified.');
  // }
  return;
};

export default {
  async beforeCreate(event: any) {
    const d = event.params.data ?? {};
    if (d.report_month) d.report_month = normalizeMonth(d.report_month);
    await ensureUniqueCombo(strapi, d);
  },

  async beforeUpdate(event: any) {
  await preventUpdatesWhenLocked(strapi, event.params);

  const d = event.params.data ?? {};
  if (d.report_month) d.report_month = normalizeMonth(d.report_month);
  },

  async afterCreate(event: any) {
    //await lockIfPublished(strapi, event.result);
  },
  async afterUpdate(event: any) {
  console.log('After update - data:', event.params.data);
  console.log('After update - result:', event.result);
  
  // Ne rien faire automatiquement - laisser le contrôle au frontend
  // Le verrouillage doit être explicite via handleLockReport
}
} as any;


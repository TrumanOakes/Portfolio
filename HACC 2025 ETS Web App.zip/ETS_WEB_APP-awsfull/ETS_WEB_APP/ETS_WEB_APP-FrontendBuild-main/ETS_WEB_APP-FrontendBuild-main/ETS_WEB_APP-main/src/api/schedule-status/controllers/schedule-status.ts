/**
 * schedule-status controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::schedule-status.schedule-status');

const toDays = (end?: string | Date, base?: string | Date) => {
  if (!end || !base) return null;
  const d = Math.floor((new Date(end).getTime() - new Date(base).getTime()) / 86_400_000);
  return Number.isFinite(d) ? d : null;
};

const compute = (data: any) => {
  if (!data) return;

  // hardening
  delete data.variance_days;

  const v = toDays(data.current_end, data.baseline_end);
  if (v !== null) data.variance_days = v;
};

export default {
  beforeCreate(event: any) {
    compute(event.params.data);
  },
  beforeUpdate(event: any) {
    compute(event.params.data);
  },
} as any;


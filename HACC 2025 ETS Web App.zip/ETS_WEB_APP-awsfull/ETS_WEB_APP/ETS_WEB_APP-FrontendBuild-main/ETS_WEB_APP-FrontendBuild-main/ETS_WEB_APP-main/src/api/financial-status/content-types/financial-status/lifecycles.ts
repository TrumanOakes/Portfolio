const compute = (data: any) => {
  if (!data) return;

  // hardening
  delete data.flag_over_budget;

  const award = Number(data.original_award_amount);
  const paid  = Number(data.total_paid_to_date);
  if (!Number.isNaN(award) && !Number.isNaN(paid)) {
    data.flag_over_budget = paid > award;
  }
};

export default {
  beforeCreate(event: any) {
    compute(event.params.data);
  },
  beforeUpdate(event: any) {
    compute(event.params.data);
  },
} as any;


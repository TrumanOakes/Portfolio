/**
 * financial-status router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::financial-status.financial-status');

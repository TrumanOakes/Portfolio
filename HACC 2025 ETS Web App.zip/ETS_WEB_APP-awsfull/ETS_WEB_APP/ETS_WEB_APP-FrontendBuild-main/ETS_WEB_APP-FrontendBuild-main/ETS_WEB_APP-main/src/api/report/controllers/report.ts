import { factories } from '@strapi/strapi';

/**
 * Custom controller for Report
 * - évite l’op-chaining / nullish-coalescing qui posaient des erreurs TS
 * - n’utilise pas de spread sur ctx.query.filters (Strapi attend un objet `filters`)
 */
export default factories.createCoreController('api::report.report', ({ strapi }) => ({
  async find(ctx) {
    // Récupération "safe" des query params
    const q: any = (ctx as any).query || {};

    // Filters robustes et typés
    const filtersObj: Record<string, unknown> =
      q && typeof q.filters === 'object' ? (q.filters as Record<string, unknown>) : {};

    const start = typeof q.start === 'number' ? q.start : Number(q.start ?? 0) || 0;
    const limit = typeof q.limit === 'number' ? q.limit : Number(q.limit ?? 25) || 25;
    const sort = q.sort ?? 'createdAt:desc';

    const data = await strapi.entityService.findMany('api::report.report', {
      filters: filtersObj,
      populate: {
        project: true,
        financial_status: true,
        schedule_status: true,
        issues: true,
      },
      sort,
      start,
      limit,
    });

    ctx.body = { data, meta: {} };
  },

  async findOne(ctx) {
    const id = Number((ctx as any).params?.id);
    const data = await strapi.entityService.findOne('api::report.report', id, {
      populate: { project: true, financial_status: true, schedule_status: true, issues: true },
    });
    ctx.body = { data, meta: {} };
  },
  // AJOUTER CETTE MÉTHODE
  async update(ctx) {
    const documentId = (ctx as any).params?.id;
    const data = (ctx as any).request?.body?.data || {};
    
    console.log('Custom update called with documentId:', documentId);
    console.log('Update data:', data);
    
    // Utiliser documentId pour l'update
    const result = await strapi.documents('api::report.report').update({
      documentId: documentId,
      data: data,
      populate: {
        project: true,
        financial_status: true,
        schedule_status: true,
        issues: true,
      }
    });
    
    ctx.body = { data: result, meta: {} };
  }
}));


// /* eslint-disable @typescript-eslint/no-explicit-any */
// import type { Core } from "@strapi/strapi";

// const isVendorOwner = async (ctx: any, config: any, { strapi }: { strapi: Core.Strapi }) => {
//   const user = ctx.state?.user;
//   if (!user) return false;

//   const userId = user.id;
//   const method = ctx.request.method;
//   const uid = config?.uid ?? ctx.state?.route?.uid;

//   // ============================================
//   // 1️⃣ ADMIN = toujours autorisé
//   // ============================================
//   try {
//     const role = await strapi.db.query("plugin::users-permissions.role").findOne({
//       where: { id: user.role },
//     });

//     if (role?.name === "Admin") {
//       return true;
//     }
//   } catch (err) {
//     // Sécurité : si on ne peut pas lire le rôle, on bloque
//     return false;
//   }

//   // ============================================
//   // 2️⃣ POST: création → on vérifie sur le body
//   // ============================================
//   if (method === "POST") {
//     const vendorId = ctx.request.body?.data?.vendor;

//     if (!vendorId) return false;

//     // l'utilisateur doit être le vendor
//     return vendorId === userId;
//   }

//   // ============================================
//   // 3️⃣ GET / PUT / DELETE : on vérifie l'entité existante
//   // ============================================
//   const idParam = ctx.params?.id;
//   if (!uid || !idParam) return false;

//   const entity: any = await strapi.entityService.findOne(uid, Number(idParam), {
//     populate: {
//       vendor: true,
//       report: {
//         populate: {
//           vendor: true,
//           project: { populate: { vendor: true } },
//         },
//       },
//     },
//   });

//   if (!entity) return false;

//   // On cherche l’owner dans toutes les relations possibles
//   const ownerId =
//     entity?.vendor?.id ??
//     entity?.report?.vendor?.id ??
//     entity?.report?.project?.vendor?.id ??
//     null;

//   return ownerId === userId;
// };

// export default isVendorOwner;

import API from '../apis';
const authService = {
  login: async (identifier, password) => {
    try {
      const response = await API.login(identifier, password);
      const {
        jwt,
        user
      } = response;
      if (!jwt || !user) {
        throw new Error('Invalid response from server');
      }
      const role = determineRoleFromEmail(identifier);
      const userData = {
        id: user.id,
        email: user.email,
        name: user.username || user.email,
        role: role,
        strapiUser: user
      };
      localStorage.setItem('ivvUser', JSON.stringify(userData));
      return {
        success: true,
        user: userData
      };
    } catch (error) {
      return {
        success: false,
        error: typeof error === 'string' ? error : error.response?.data?.error?.message || error.message || 'Login failed. Please check your credentials.'
      };
    }
  },
  logout: () => {
    localStorage.removeItem('ivvUser');
    API.logout();
  },
  getCurrentUser: async () => {
    try {
      const response = await API.getCurrentUser();
      return {
        success: true,
        user: response.data
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },
  isAuthenticated: () => {
    return !!localStorage.getItem('jwt') || !!localStorage.getItem('ivvUser');
  }
};
const determineRoleFromEmail = email => {
  const emailLower = email.toLowerCase();
  if (emailLower.includes('admin') || emailLower.includes('@ets.gov')) {
    return 'admin';
  }
  if (emailLower.includes('vendor') || emailLower.includes('@techassure')) {
    return 'vendor';
  }
  return 'vendor';
};
export default authService;
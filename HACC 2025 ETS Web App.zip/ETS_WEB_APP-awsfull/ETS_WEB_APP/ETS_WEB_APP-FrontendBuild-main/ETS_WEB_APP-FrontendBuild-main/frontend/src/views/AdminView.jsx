import React, { useEffect, useState } from 'react';
import { Plus, Edit, Save, X, Lock, Unlock, FileText, AlertCircle, TrendingUp, DollarSign, Eye, Trash2, Users, Settings, Activity, BarChart3, CheckCircle, XCircle, Clock, Download, Upload, Search, Filter } from 'lucide-react';
import API from '../apis';
import { normalizeReport } from '../utils/normalize';
import StatCard from '../components/common/StatCard';
import ProjectCard from '../components/common/ProjectCard';
import ScheduleTimeline from '../components/charts/ScheduleTimeline';
import FinancialSummary from '../components/charts/FinancialSummary';
import ScopeSummary from '../components/charts/ScopeTracker';
import IssueSummary from '../components/issues/IssueTable';
import ReportExportButtons from "../components/ReportExportButtons";
import NewProjectModal from '../components/modals/NewProjectModal';
import EditProjectModal from '../components/modals/EditProjectModal';
import NewVendorModal from '../components/modals/NewVendorModal';
import EditVendorModal from '../components/modals/EditVendorModal';
import EditReportModal from '../components/modals/EditReportModal';
const tabs = [{
  id: 'dashboard',
  name: 'Dashboard',
  icon: BarChart3
}, {
  id: 'projects',
  name: 'Projects',
  icon: FileText
}, {
  id: 'reports',
  name: 'Reports Management',
  icon: CheckCircle
}, {
  id: 'vendors',
  name: 'Vendors',
  icon: Users
}, {
  id: 'settings',
  name: 'Settings',
  icon: Settings
}];
const AdminView = ({
  selectedProject,
  setSelectedProject,
  user
}) => {
  const [projects, setProjects] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [allReports, setAllReports] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [selectedTab, setSelectedTab] = useState('dashboard');
  const [selectedSubTab, setSelectedSubTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showNewProject, setShowNewProject] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [showNewVendor, setShowNewVendor] = useState(false);
  const [editingVendor, setEditingVendor] = useState(null);
  const [editingReport, setEditingReport] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [vendorFilter, setVendorFilter] = useState('all');
  useEffect(() => {
    const loadAdminData = async () => {
      if (!user?.id) return;
      try {
        setLoading(true);
        const projectsRes = await API.get('/projects?populate=*');
        if (projectsRes.data?.data) {
          const normalizedProjects = projectsRes.data.data.map(project => ({
            id: project.id,
            documentId: project.documentId,
            title: project.title || `Project #${project.id}`,
            agency: project.agency || 'Unknown Agency',
            status: project.project_status || 'Active',
            description: project.description || '',
            vendor: project.users_permissions_user ? {
              id: project.users_permissions_user.id,
              name: project.users_permissions_user.username || project.users_permissions_user.email
            } : null
          }));
          setProjects(normalizedProjects);
        }
        const vendorsRes = await API.get('/users?filters[role][name][$eq]=Vendor');
        if (vendorsRes.data) {
          setVendors(vendorsRes.data);
        }
        const reportsRes = await API.get('/reports?populate=*&sort=report_month:desc');
        if (reportsRes.data?.data) {
          const normalizedReports = reportsRes.data.data.map(report => normalizeReport(report));
          setAllReports(normalizedReports);
        }
      } catch (err) {
        setError('Failed to load admin dashboard data.');
      } finally {
        setLoading(false);
      }
    };
    loadAdminData();
  }, [user]);
  const reloadAdminData = async () => {
    if (!user?.id) return;
    try {
      const projectsRes = await API.get('/projects?populate=*');
      if (projectsRes.data?.data) {
        const normalizedProjects = projectsRes.data.data.map(project => ({
          id: project.id,
          documentId: project.documentId,
          title: project.title || `Project #${project.id}`,
          agency: project.agency || 'Unknown Agency',
          status: project.project_status || 'Active',
          description: project.description || '',
          vendor: project.users_permissions_user ? {
            id: project.users_permissions_user.id,
            name: project.users_permissions_user.username || project.users_permissions_user.email
          } : null
        }));
        setProjects(normalizedProjects);
      }
      const vendorsRes = await API.get('/users?filters[role][name][$eq]=Vendor');
      if (vendorsRes.data) {
        setVendors(vendorsRes.data);
      }
      const reportsRes = await API.get('/reports?populate=*&sort=report_month:desc');
      if (reportsRes.data?.data) {
        const normalizedReports = reportsRes.data.data.map(report => normalizeReport(report));
        setAllReports(normalizedReports);
      }
    } catch (err) {}
  };
  const handleCreateProject = async projectData => {
    try {
      const newProject = {
        title: projectData.title,
        slug: projectData.slug,
        agency: projectData.agency,
        description: projectData.description,
        project_status: projectData.status,
        users_permissions_user: projectData.vendorId || null
      };
      await API.post('/projects', {
        data: newProject
      });
      await reloadAdminData();
      setShowNewProject(false);
      alert('✅ Project created successfully!');
    } catch (err) {
      alert(`Failed to create project: ${err.response?.data?.error?.message || err.message}`);
    }
  };
  const handleUpdateProject = async (projectId, updates) => {
    try {
      const projectToUpdate = projects.find(project => project.id === projectId);
      const documentId = projectToUpdate?.documentId;
      if (!documentId) {
        alert('Cannot update project: missing documentId');
        return;
      }
      await API.put(`/projects/${documentId}`, {
        data: updates
      });
      await reloadAdminData();
      setEditingProject(null);
      alert('✅ Project updated successfully!');
    } catch (err) {
      alert(`Failed to update project: ${err.response?.data?.error?.message || err.message}`);
    }
  };
  const handleDeleteProject = async projectId => {
    if (window.confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
      try {
        const projectToDelete = projects.find(project => project.id === projectId);
        const documentId = projectToDelete?.documentId;
        if (!documentId) {
          alert('Cannot delete project: missing documentId');
          return;
        }
        await API.delete(`/projects/${documentId}`);
        await reloadAdminData();
        alert('✅ Project deleted successfully!');
      } catch (err) {
        alert(`Failed to delete project: ${err.response?.data?.error?.message || err.message}`);
      }
    }
  };
  const handleAssignVendorToProject = async (projectId, vendorId) => {
    try {
      const projectToUpdate = projects.find(project => project.id === projectId);
      const documentId = projectToUpdate?.documentId;
      if (!documentId) {
        alert('Cannot assign vendor: missing project documentId');
        return;
      }
      const updates = {
        users_permissions_user: vendorId
      };
      await API.put(`/projects/${documentId}`, {
        data: updates
      });
      await reloadAdminData();
      alert('✅ Vendor assigned successfully!');
    } catch (err) {
      alert(`Failed to assign vendor: ${err.response?.data?.error?.message || err.message}`);
    }
  };
  const handleCreateVendor = async vendorData => {
    try {
      const newUser = {
        username: vendorData.username,
        email: vendorData.email,
        password: vendorData.password
      };
      const userResponse = await API.post('/auth/local/register', newUser);
      const createdUser = userResponse.data.user;
      const updateResponse = await API.put(`/users/${createdUser.id}`, {
        role: 3
      });
      await reloadAdminData();
      setShowNewVendor(false);
      alert('✅ Vendor created successfully!');
    } catch (err) {
      if (err.response?.data?.error?.message?.includes('Email or Username are already taken')) {
        alert('❌ Email or Username already exists. Please choose different credentials.');
      } else {
        alert(`Failed to create vendor: ${err.response?.data?.error?.message || err.message}`);
      }
    }
  };
  const handleUpdateVendor = async (vendorId, updates) => {
    try {
      await API.put(`/users/${vendorId}`, updates);
      await reloadAdminData();
      setEditingVendor(null);
      alert('✅ Vendor updated successfully!');
    } catch (err) {
      alert(`Failed to update vendor: ${err.response?.data?.error?.message || err.message}`);
    }
  };
  const handleDeleteVendor = async vendorId => {
    if (window.confirm('Are you sure you want to delete this vendor? This action cannot be undone.')) {
      try {
        await API.delete(`/users/${vendorId}`);
        await reloadAdminData();
        alert('✅ Vendor deleted successfully!');
      } catch (err) {
        alert(`Failed to delete vendor: ${err.response?.data?.error?.message || err.message}`);
      }
    }
  };
  const handleUnlockReport = async reportId => {
    if (window.confirm('Are you sure you want to unlock this report? The vendor will be able to edit it again.')) {
      try {
        const reportToUnlock = allReports.find(report => report.id === reportId);
        const documentId = reportToUnlock?.documentId;
        if (!documentId) {
          alert('Cannot unlock report: missing documentId');
          return;
        }
        await API.put(`/reports/${documentId}`, {
          data: {
            locked: false
          }
        });
        await reloadAdminData();
        alert('✅ Report unlocked successfully! Vendor can now edit it.');
      } catch (err) {
        alert(`Failed to unlock report: ${err.response?.data?.error?.message || err.message}`);
      }
    }
  };
  const handleDeleteReport = async reportId => {
    if (window.confirm('Are you sure you want to delete this report? This action cannot be undone.')) {
      try {
        const reportToDelete = allReports.find(report => report.id === reportId);
        const documentId = reportToDelete?.documentId;
        if (!documentId) {
          alert('Cannot delete report: missing documentId');
          return;
        }
        await API.delete(`/reports/${documentId}`);
        await reloadAdminData();
        alert('✅ Report deleted successfully!');
      } catch (err) {
        alert(`Failed to delete report: ${err.response?.data?.error?.message || err.message}`);
      }
    }
  };
  const handleEditReport = async (reportId, updates) => {
    try {
      const reportToUpdate = allReports.find(report => report.id === reportId);
      const documentId = reportToUpdate?.documentId;
      if (!documentId) {
        alert('Cannot update report: missing documentId');
        return;
      }
      const reportUpdates = {};
      if (updates.month !== undefined) reportUpdates.report_month = updates.month;
      if (updates.summary !== undefined) reportUpdates.summary = updates.summary;
      if (Object.keys(reportUpdates).length > 0) {
        await API.put(`/reports/${documentId}`, {
          data: reportUpdates
        });
      }
      const scheduleDocumentId = reportToUpdate?.schedule?.documentId;
      const financialDocumentId = reportToUpdate?.financial?.documentId;
      if (updates.financial || updates.scope || updates.schedule) {
        if (scheduleDocumentId) {
          const scheduleUpdates = {};
          if (updates.schedule) {
            if (updates.schedule.baselineStart !== undefined) scheduleUpdates.baseline_start = updates.schedule.baselineStart;
            if (updates.schedule.baselineEnd !== undefined) scheduleUpdates.baseline_end = updates.schedule.baselineEnd;
            if (updates.schedule.currentStart !== undefined) scheduleUpdates.current_start = updates.schedule.currentStart;
            if (updates.schedule.currentEnd !== undefined) scheduleUpdates.current_end = updates.schedule.currentEnd;
            if (updates.schedule.variance !== undefined) scheduleUpdates.variance_days = updates.schedule.variance;
            if (updates.schedule.notes !== undefined) scheduleUpdates.schedule_notes = updates.schedule.notes;
          }
          if (updates.scope) {
            if (updates.scope.total !== undefined) scheduleUpdates.deliverables_commited = updates.scope.total;
            if (updates.scope.completed !== undefined) scheduleUpdates.deliverables_completed = updates.scope.completed;
            if (updates.scope.notes !== undefined) scheduleUpdates.scope_notes = updates.scope.notes;
            if (updates.scope.total !== undefined && updates.scope.completed !== undefined) {
              scheduleUpdates.percent_complete = updates.scope.total > 0 ? Math.round(updates.scope.completed / updates.scope.total * 100) : 0;
            }
          }
          if (Object.keys(scheduleUpdates).length > 0) {
            await API.put(`/schedule-statuses/${scheduleDocumentId}`, {
              data: scheduleUpdates
            });
          }
        }
      }
      if (updates.financial && financialDocumentId) {
        const financialUpdates = {
          original_award_amount: updates.financial.originalAmount,
          total_paid_to_date: updates.financial.paidToDate,
          flag_over_budget: updates.financial.overBudget,
          notes: updates.financial.notes
        };
        if (Object.keys(financialUpdates).length > 0) {
          await API.put(`/financial-statuses/${financialDocumentId}`, {
            data: financialUpdates
          });
        }
      }
      await reloadAdminData();
      setEditingReport(null);
      alert('✅ Report updated successfully by admin!');
    } catch (err) {
      alert(`Failed to update report: ${err.response?.data?.error?.message || err.message}`);
    }
  };
  const handleApproveReport = async reportId => {
    if (window.confirm('Approve this report for public viewing?')) {
      try {
        const reportToApprove = allReports.find(report => report.id === reportId);
        const documentId = reportToApprove?.documentId;
        await API.put(`/reports/${documentId}`, {
          data: {
            report_status: "Approved",
            locked: true
          }
        });
        await reloadAdminData();
        alert('✅ Report approved and published!');
      } catch (err) {
        alert('Failed to approve report.');
      }
    }
  };
  const handleRejectReport = async reportId => {
    if (window.confirm('Reject this report? It will be sent back to draft.')) {
      try {
        const reportToReject = allReports.find(report => report.id === reportId);
        const documentId = reportToReject?.documentId;
        await API.put(`/reports/${documentId}`, {
          data: {
            report_status: "Draft",
            locked: false
          }
        });
        await reloadAdminData();
        alert('📝 Report rejected and sent back to vendor.');
      } catch (err) {
        alert('Failed to reject report.');
      }
    }
  };
  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) || project.agency.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || project.status === statusFilter;
    const matchesVendor = vendorFilter === 'all' || project.vendor?.id.toString() === vendorFilter;
    return matchesSearch && matchesStatus && matchesVendor;
  });
  const filteredReports = allReports.filter(report => {
    const matchesSearch = searchTerm === '' || report.projectTitle && report.projectTitle.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });
  const stats = {
    totalProjects: projects.length,
    totalVendors: vendors.length,
    totalReports: allReports.length,
    submittedReports: allReports.filter(r => r.locked).length,
    draftReports: allReports.filter(r => !r.locked).length,
    totalIssues: allReports.reduce((sum, r) => sum + (r.issues?.length || 0), 0),
    openIssues: allReports.reduce((sum, r) => sum + (r.issues?.filter(i => i.status === 'Open').length || 0), 0)
  };
  if (loading) {
    return <div className="p-6 text-gray-500 dark:text-gray-400">Loading admin dashboard...</div>;
  }
  if (error) {
    return <div className="p-6 text-red-600 dark:text-red-400">{error}</div>;
  }
  if (!user) {
    return <div className="p-6 text-gray-600 dark:text-gray-300">Please login to access the admin dashboard.</div>;
  }
  if (selectedProject) {
    const project = projects.find(p => p.id === selectedProject);
    const projectReports = allReports.filter(r => r.projectId === selectedProject);
    return <div className="space-y-6">
        {}
        <div className="flex items-center justify-between">
          <button onClick={() => setSelectedProject(null)} className="text-blue-600 hover:text-blue-800 font-medium">
            ← Back to Admin Dashboard
          </button>
          <div className="flex gap-2">
            <button onClick={() => setEditingProject(project)} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
              <Edit className="w-4 h-4" />
              Edit Project
            </button>
            <button onClick={() => handleDeleteProject(project.id)} className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
              <Trash2 className="w-4 h-4" />
              Delete Project
            </button>
          </div>
        </div>

        {}
        <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700 transition-colors duration-200">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">{project?.title}</h1>
          <p className="text-gray-600 dark:text-gray-300">{project?.agency}</p>
          <div className="flex items-center space-x-4 mt-3">
            <span className="px-3 py-1 rounded-full bg-green-100 text-green-700 text-sm">
              {project?.status}
            </span>
            <span className="text-sm text-gray-500 dark:text-gray-300">
              Vendor: {project?.vendor?.name || 'Not assigned'}
            </span>
            {!project?.vendor && <button onClick={() => {}} className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded hover:bg-blue-200">
                Assign Vendor
              </button>}
          </div>
        </div>

        {}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <StatCard title="Total Reports" value={projectReports.length} icon={FileText} subtitle="All reports" color="blue" />
          <StatCard title="Draft Reports" value={projectReports.filter(r => !r.locked).length} icon={Edit} subtitle="Editable" color="orange" />
          <StatCard title="Submitted Reports" value={projectReports.filter(r => r.locked).length} icon={Lock} subtitle="Final reports" color="green" />
          <StatCard title="Total Issues" value={projectReports.reduce((sum, r) => sum + (r.issues?.length || 0), 0)} icon={AlertCircle} subtitle="All issues" color="red" />
        </div>

        {}
        <div className="bg-white rounded-lg shadow border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold">Project Reports (Admin View)</h2>
            <p className="text-sm text-gray-600 mt-1">
              As admin, you can edit, unlock, and delete any report
            </p>
          </div>
          <div className="p-6">
            {projectReports.length > 0 ? <div className="space-y-4">
                {projectReports.map(report => <div key={report.id} className="border border-gray-200 dark:border-slate-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                           <h3 className="font-semibold text-lg text-gray-900 dark:text-gray-100">
                            {report.reportMonth ? new Date(report.reportMonth).toLocaleDateString(undefined, {
                        year: 'numeric',
                        month: 'long'
                      }) : 'Report'}
                          </h3>
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${report.locked ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                            {report.locked ? '🔒 Submitted' : '📝 Draft'}
                          </span>
                          {report.locked && <span className="px-2 py-1 rounded text-xs bg-blue-100 text-blue-800">
                              Admin can override
                            </span>}
                        </div>
                        
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                          {report.summary || 'No summary provided'}
                        </p>
                        
                        <div className="flex gap-4 text-xs text-gray-500 dark:text-gray-400">
                          <span>Issues: {report.issues?.length || 0}</span>
                          <span>Created: {report.reportMonth ? new Date(report.reportMonth).toLocaleDateString() : 'Unknown'}</span>
                          <span>Vendor: {project?.vendor?.name || 'Unassigned'}</span>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <button onClick={() => setSelectedReport(report)} className="text-blue-600 hover:text-blue-800" title="View Report Details">
                          <Eye className="w-5 h-5" />
                        </button>
                        
                        <button onClick={() => setEditingReport(report)} className="text-blue-600 hover:text-blue-800" title="Edit Report (Admin Override)">
                          <Edit className="w-5 h-5" />
                        </button>
                        
                        {report.locked && <button onClick={() => handleUnlockReport(report.id)} className="text-orange-600 hover:text-orange-800" title="Unlock Report for Vendor">
                            <Unlock className="w-5 h-5" />
                          </button>}
                        
                        <button onClick={() => handleDeleteReport(report.id)} className="text-red-600 hover:text-red-800" title="Delete Report">
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>)}
              </div> : <div className="text-center py-8">
                <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-300 text-lg mb-2">No reports found for this project</p>
                <p className="text-gray-500 dark:text-gray-400 text-sm">
                  Reports will appear here once the assigned vendor creates them.
                </p>
              </div>}
          </div>
        </div>

      </div>;
  }
  if (selectedReport) {
    const reportProject = projects.find(p => p.id === selectedReport.projectId);
    return <div className="space-y-6">
      {}
      <div className="bg-white rounded-lg shadow border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Report Details (Admin View)</h1>
              <p className="text-gray-600 mt-1">
                {reportProject?.title || 'Unknown Project'} - {selectedReport.reportMonth ? new Date(selectedReport.reportMonth).toLocaleDateString() : 'Unknown Date'}
              </p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setEditingReport(selectedReport)} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                <Edit className="w-4 h-4" />
                Edit Report
              </button>
              <button onClick={() => setSelectedReport(null)} className="flex items-center gap-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
                <X className="w-4 h-4" />
                Back to List
              </button>
            </div>
          </div>
        </div>
        
        {}
        <div className="p-6 bg-gray-50 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${selectedReport.report_status === 'Draft' ? 'bg-orange-100 text-orange-800' : selectedReport.report_status === 'Submitted' ? 'bg-yellow-100 text-yellow-800' : selectedReport.report_status === 'Approved' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                {selectedReport.report_status === 'Draft' ? '📝 Draft' : selectedReport.report_status === 'Submitted' ? '⏳ Awaiting Approval' : selectedReport.report_status === 'Approved' ? '✅ Approved' : selectedReport.report_status}
              </span>
              
              {selectedReport.locked && <span className="px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
                  🔒 Locked
                </span>}
            </div>
            
            {}
            <div className="flex gap-2">
              {selectedReport.report_status === 'Submitted' && <>
                  <button onClick={() => handleApproveReport(selectedReport.id)} className="flex items-center gap-2 bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700">
                    <CheckCircle className="w-4 h-4" />
                    Approve
                  </button>
                  <button onClick={() => handleRejectReport(selectedReport.id)} className="flex items-center gap-2 bg-red-600 text-white px-3 py-2 rounded-lg hover:bg-red-700">
                    <XCircle className="w-4 h-4" />
                    Reject
                  </button>
                </>}
              
              {selectedReport.locked && <button onClick={() => handleUnlockReport(selectedReport.id)} className="flex items-center gap-2 bg-orange-600 text-white px-3 py-2 rounded-lg hover:bg-orange-700">
                  <Unlock className="w-4 h-4" />
                  Unlock
                </button>}
            </div>
          </div>
        </div>
      </div>

      {}
      <ReportExportButtons report={selectedReport} project={reportProject} />

              {}
              <div id="report-export-container" className="space-y-6 mt-4">

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pdf-grid-section">
              <ScheduleTimeline report={selectedReport} />
              <FinancialSummary report={selectedReport} />
            </div>

            <ScopeSummary report={selectedReport} />
            <IssueSummary issues={selectedReport?.issues || []} />

          </div>
    </div>;
  }
  return <div className="space-y-6">
  {}
  <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700 transition-colors duration-200">
    <div className="flex justify-between items-center">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-slate-100 mb-2">
          Admin Dashboard
        </h1>
        <p className="text-gray-600 dark:text-slate-300">
          Welcome, {user.username || user.email}. Manage all ETS IV&V projects, vendors, and reports.
        </p>
      </div>
          <div className="flex gap-2">
            <button onClick={() => setShowNewProject(true)} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
              <Plus className="w-4 h-4" />
              Create Project
            </button>
            <button onClick={() => setShowNewVendor(true)} className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
              <Users className="w-4 h-4" />
              Add Vendor
            </button>
          </div>
        </div>
      </div>

      {}
      <div className="flex gap-2 border-b border-gray-200 dark:border-slate-700">
  <button
    onClick={() => setSelectedTab('dashboard')}
    className={`px-4 py-2 font-medium border-b-2 ${
      selectedTab === 'dashboard'
        ? 'text-blue-600 dark:text-blue-400 border-blue-600'
        : 'border-transparent text-gray-600 dark:text-slate-300 hover:text-gray-800 dark:hover:text-slate-100'
    }`}
  >
    📊 Dashboard
  </button>
  <button
    onClick={() => setSelectedTab('projects')}
    className={`px-4 py-2 font-medium border-b-2 ${
      selectedTab === 'projects'
        ? 'text-blue-600 dark:text-blue-400 border-blue-600'
        : 'border-transparent text-gray-600 dark:text-slate-300 hover:text-gray-800 dark:hover:text-slate-100'
    }`}
  >
    🏗️ Projects
  </button>
  <button
    onClick={() => setSelectedTab('vendors')}
    className={`px-4 py-2 font-medium border-b-2 ${
      selectedTab === 'vendors'
        ? 'text-blue-600 dark:text-blue-400 border-blue-600'
        : 'border-transparent text-gray-600 dark:text-slate-300 hover:text-gray-800 dark:hover:text-slate-100'
    }`}
  >
    👥 Vendors
  </button>
  <button
    onClick={() => setSelectedTab('reports')}
    className={`px-4 py-2 font-medium border-b-2 ${
      selectedTab === 'reports'
        ? 'text-blue-600 dark:text-blue-400 border-blue-600'
        : 'border-transparent text-gray-600 dark:text-slate-300 hover:text-gray-800 dark:hover:text-slate-100'
    }`}
  >
    📄 Reports
  </button>
</div>


      {}
      {selectedTab === 'dashboard' && <>
  {/* Top stat cards (already dark-aware via StatCard) */}
  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
    <StatCard title="Total Projects" value={stats.totalProjects} icon={FileText} subtitle="Active projects" color="blue" />
    <StatCard title="IV&V Vendors" value={stats.totalVendors} icon={Users} subtitle="Registered vendors" color="green" />
    <StatCard title="Total Reports" value={stats.totalReports} icon={BarChart3} subtitle={`${stats.submittedReports} submitted, ${stats.draftReports} drafts`} color="purple" />
    <StatCard title="Open Issues" value={stats.openIssues} icon={AlertCircle} subtitle={`${stats.totalIssues} total issues`} color="orange" />
  </div>

  {/* Recent Activity + Project Status Overview */}
  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
    {/* Recent Activity */}
    <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 p-6 transition-colors duration-200">
      <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-slate-100">
        Recent Activity
      </h3>
      <div className="space-y-4">
        {allReports.slice(0, 5).map((report) => (
          <div key={report.id} className="flex items-start gap-3 text-sm">
            <div
              className={`w-2 h-2 rounded-full mt-2 ${
                report.locked ? "bg-green-500" : "bg-orange-500"
              }`}
            ></div>
            <div className="flex-1">
              <p className="font-medium text-gray-900 dark:text-slate-100">
                {report.locked ? "Report submitted" : "Draft created"} for{" "}
                <span className="text-blue-600 dark:text-blue-400">
                  {projects.find((p) => p.id === report.projectId)?.title ||
                    "Unknown Project"}
                </span>
              </p>
              <p className="text-gray-600 dark:text-slate-300 text-xs">
                {projects.find((p) => p.id === report.projectId)?.vendor?.name ||
                  "Unknown Vendor"}{" "}
                •{" "}
                {report.reportMonth
                  ? new Date(report.reportMonth).toLocaleDateString()
                  : "No date"}
              </p>
            </div>
          </div>
        ))}
        {allReports.length === 0 && (
          <p className="text-gray-500 dark:text-slate-400 text-center py-4">
            No recent activity
          </p>
        )}
      </div>
    </div>

    {/* Project Status Overview */}
    <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 p-6 transition-colors duration-200">
      <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-slate-100">
        Project Status Overview
      </h3>
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600 dark:text-slate-300">
            Active Projects
          </span>
          <span className="font-semibold text-green-600">
            {projects.filter((p) => p.status === "Active").length}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600 dark:text-slate-300">
            Projects with Vendors
          </span>
          <span className="font-semibold text-blue-600">
            {projects.filter((p) => p.vendor).length}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600 dark:text-slate-300">
            Unassigned Projects
          </span>
          <span className="font-semibold text-orange-600">
            {projects.filter((p) => !p.vendor).length}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600 dark:text-slate-300">
            Projects with Reports
          </span>
          <span className="font-semibold text-purple-600">
            {[...new Set(allReports.map((r) => r.projectId))].length}
          </span>
        </div>
      </div>
    </div>
  </div>
</>}

      {}
            {selectedTab === 'projects' && (
        <div className="space-y-6">
          {/* Filters */}
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 p-4 transition-colors duration-200">
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex-1 min-w-64">
                <div className="relative">
                  <Search
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500 w-4 h-4"
                  />
                  <input
                    type="text"
                    placeholder="Search projects..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Status</option>
                <option value="Active">Active</option>
                <option value="Completed">Completed</option>
                <option value="OnHold">On Hold</option>
              </select>

              <select
                value={vendorFilter}
                onChange={(e) => setVendorFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Vendors</option>
                <option value="">Unassigned</option>
                {vendors.map((vendor) => (
                  <option key={vendor.id} value={vendor.id}>
                    {vendor.username || vendor.email}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Projects table */}
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 transition-colors duration-200">
            <div className="p-6 border-b border-gray-200 dark:border-slate-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
                  All Projects ({filteredProjects.length})
                </h2>
                <button
                  onClick={() => setShowNewProject(true)}
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4" />
                  Create Project
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-slate-800">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase text-gray-500 dark:text-gray-300">
                      Project
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase text-gray-500 dark:text-gray-300">
                      Agency
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase text-gray-500 dark:text-gray-300">
                      Vendor
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase text-gray-500 dark:text-gray-300">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase text-gray-500 dark:text-gray-300">
                      Reports
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase text-gray-500 dark:text-gray-300">
                      Actions
                    </th>
                  </tr>
                </thead>

                <tbody className="bg-white dark:bg-slate-900 divide-y divide-gray-200 dark:divide-slate-700">
                  {filteredProjects.map((project) => {
                    const projectReports = allReports.filter(
                      (r) => r.projectId === project.id
                    );

                    return (
                      <tr
                        key={project.id}
                        className="hover:bg-gray-50 dark:hover:bg-slate-800"
                      >
                        <td className="px-6 py-4">
                          <button
                            onClick={() => setSelectedProject(project.id)}
                            className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 font-medium text-left"
                          >
                            {project.title}
                          </button>
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            {project.description}
                          </p>
                        </td>

                        <td className="px-6 py-4 text-sm text-gray-900 dark:text-gray-100">
                          {project.agency}
                        </td>

                        <td className="px-6 py-4 text-sm">
                          {project.vendor ? (
                            <span className="text-gray-900 dark:text-gray-100">
                              {project.vendor.name}
                            </span>
                          ) : (
                            <span className="text-orange-600 font-medium">
                              Unassigned
                            </span>
                          )}
                        </td>

                        <td className="px-6 py-4">
                          <span className="inline-flex px-3 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                            {project.status}
                          </span>
                        </td>

                        <td className="px-6 py-4 text-sm text-gray-900 dark:text-gray-100">
                          <div className="flex gap-2 text-xs">
                            <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                              {projectReports.length} total
                            </span>
                            <span className="bg-green-100 text-green-800 px-2 py-1 rounded">
                              {projectReports.filter((r) => r.locked).length}{" "}
                              submitted
                            </span>
                          </div>
                        </td>

                        <td className="px-6 py-4">
                          <div className="flex gap-2">
                            <button
                              onClick={() => setEditingProject(project)}
                              className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                              title="Edit Project"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteProject(project.id)}
                              className="text-red-600 hover:text-red-800"
                              title="Delete Project"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}


      {}
            {selectedTab === 'vendors' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 transition-colors duration-200">
            <div className="p-6 border-b border-gray-200 dark:border-slate-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
                  IV&V Vendors ({vendors.length})
                </h2>
                <button
                  onClick={() => setShowNewVendor(true)}
                  className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                >
                  <Plus className="w-4 h-4" />
                  Add Vendor
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-slate-800">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                      Vendor
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                      Email
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                      Assigned Projects
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                      Reports
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                      Actions
                    </th>
                  </tr>
                </thead>

                <tbody className="bg-white dark:bg-slate-900 divide-y divide-gray-200 dark:divide-slate-700">
                  {vendors.map((vendor) => {
                    const vendorProjects = projects.filter(
                      (p) => p.vendor?.id === vendor.id
                    );
                    const vendorReports = allReports.filter((r) =>
                      vendorProjects.some((p) => p.id === r.projectId)
                    );

                    return (
                      <tr
                        key={vendor.id}
                        className="hover:bg-gray-50 dark:hover:bg-slate-800"
                      >
                        <td className="px-6 py-4">
                          <div className="font-medium text-gray-900 dark:text-gray-100">
                            {vendor.username}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            ID: {vendor.id}
                          </div>
                        </td>

                        <td className="px-6 py-4 text-sm text-gray-900 dark:text-gray-100">
                          {vendor.email}
                        </td>

                        <td className="px-6 py-4 text-sm">
                          <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                            {vendorProjects.length} projects
                          </span>
                        </td>

                        <td className="px-6 py-4 text-sm">
                          <div className="flex gap-1 text-xs">
                            <span className="bg-green-100 text-green-800 px-2 py-1 rounded">
                              {vendorReports.filter((r) => r.locked).length}{' '}
                              submitted
                            </span>
                            <span className="bg-orange-100 text-orange-800 px-2 py-1 rounded">
                              {vendorReports.filter((r) => !r.locked).length}{' '}
                              drafts
                            </span>
                          </div>
                        </td>

                        <td className="px-6 py-4">
                          <div className="flex gap-2">
                            <button
                              onClick={() => setEditingVendor(vendor)}
                              className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                              title="Edit Vendor"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteVendor(vendor.id)}
                              className="text-red-600 hover:text-red-800"
                              title="Delete Vendor"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}


            {selectedTab === 'reports' && (
        <div className="space-y-6">
          {/* Filters + header */}
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 transition-colors duration-200">
            <div className="p-6 border-b border-gray-200 dark:border-slate-700">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                Reports Management
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Approve, reject, or manage all vendor reports
              </p>
            </div>

            <div className="p-6 bg-gray-50 dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Status filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                    Status
                  </label>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="all">All Status</option>
                    <option value="draft">Draft</option>
                    <option value="submitted">Submitted (Awaiting Approval)</option>
                    <option value="approved">Approved (Published)</option>
                  </select>
                </div>

                {/* Vendor filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                    Vendor
                  </label>
                  <select
                    value={vendorFilter}
                    onChange={(e) => setVendorFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="all">All Vendors</option>
                    {vendors.map((vendor) => (
                      <option key={vendor.id} value={vendor.id}>
                        {vendor.username || vendor.email}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Search */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                    Search
                  </label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500 w-4 h-4" />
                    <input
                      type="text"
                      placeholder="Search reports..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Stats row (StatCard already dark-mode aware) */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard
              title="Draft Reports"
              value={allReports.filter((r) => r.report_status === 'Draft').length}
              icon={Edit}
              subtitle="In progress"
              color="orange"
            />
            <StatCard
              title="Awaiting Approval"
              value={allReports.filter((r) => r.report_status === 'Submitted').length}
              icon={Clock}
              subtitle="Need review"
              color="yellow"
            />
            <StatCard
              title="Approved Reports"
              value={allReports.filter((r) => r.report_status === 'Approved').length}
              icon={CheckCircle}
              subtitle="Published"
              color="green"
            />
            <StatCard
              title="Total Reports"
              value={allReports.length}
              icon={FileText}
              subtitle="All reports"
              color="blue"
            />
          </div>

          {/* Reports list */}
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 transition-colors duration-200">
            <div className="p-6">
              <div className="space-y-4">
                {(() => {
                  let filteredReports = allReports;

                  if (statusFilter !== 'all') {
                    filteredReports = filteredReports.filter(
                      (r) => r.report_status === statusFilter
                    );
                  }

                  if (vendorFilter !== 'all') {
                    filteredReports = filteredReports.filter((r) => {
                      const project = projects.find((p) => p.id === r.projectId);
                      return project?.vendor?.id === parseInt(vendorFilter);
                    });
                  }

                  if (searchTerm) {
                    filteredReports = filteredReports.filter((r) => {
                      const project = projects.find((p) => p.id === r.projectId);
                      return (
                        project?.title
                          ?.toLowerCase()
                          .includes(searchTerm.toLowerCase()) ||
                        r.summary?.toLowerCase().includes(searchTerm.toLowerCase())
                      );
                    });
                  }

                  return filteredReports.length > 0 ? (
                    filteredReports.map((report) => {
                      const project = projects.find(
                        (p) => p.id === report.projectId
                      );
                      const vendor = project?.vendor;

                      return (
                        <div
                          key={report.id}
                          className="border border-gray-200 dark:border-slate-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors"
                        >
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h3 className="font-semibold text-lg text-gray-900 dark:text-gray-100">
                                  {project?.title ||
                                    `Project #${report.projectId}`}
                                </h3>

                                <span
                                  className={`px-2 py-1 rounded-full text-xs font-medium ${
                                    report.report_status === 'Draft'
                                      ? 'bg-orange-100 text-orange-800'
                                      : report.report_status === 'Submitted'
                                      ? 'bg-yellow-100 text-yellow-800'
                                      : report.report_status === 'Approved'
                                      ? 'bg-green-100 text-green-800'
                                      : 'bg-gray-100 text-gray-800'
                                  }`}
                                >
                                  {report.report_status === 'Draft'
                                    ? '📝 Draft'
                                    : report.report_status === 'Submitted'
                                    ? '⏳ Awaiting Approval'
                                    : report.report_status === 'Approved'
                                    ? '✅ Approved'
                                    : report.report_status}
                                </span>
                              </div>

                              <p className="text-gray-600 dark:text-gray-300 mb-2">
                                {report.summary || 'No summary provided'}
                              </p>

                              <div className="flex gap-4 text-xs text-gray-500 dark:text-gray-400">
                                <span>Vendor: {vendor?.name || 'Unassigned'}</span>
                                <span>Issues: {report.issues?.length || 0}</span>
                                <span>
                                  Month:{' '}
                                  {report.reportMonth
                                    ? new Date(
                                        report.reportMonth
                                      ).toLocaleDateString()
                                    : 'Unknown'}
                                </span>
                              </div>
                            </div>

                            <div className="flex gap-2 ml-4">
                              <button
                                onClick={() => setSelectedReport(report)}
                                className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 p-1"
                                title="View Report Details"
                              >
                                <Eye className="w-5 h-5" />
                              </button>

                              <button
                                onClick={() => setEditingReport(report)}
                                className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 p-1"
                                title="Edit Report"
                              >
                                <Edit className="w-5 h-5" />
                              </button>

                              {report.report_status === 'Submitted' && (
                                <>
                                  <button
                                    onClick={() => handleApproveReport(report.id)}
                                    className="text-green-600 hover:text-green-800 p-1"
                                    title="Approve Report"
                                  >
                                    <CheckCircle className="w-5 h-5" />
                                  </button>
                                  <button
                                    onClick={() => handleRejectReport(report.id)}
                                    className="text-red-600 hover:text-red-800 p-1"
                                    title="Reject Report"
                                  >
                                    <XCircle className="w-5 h-5" />
                                  </button>
                                </>
                              )}

                              {report.report_status === 'Approved' && (
                                <button
                                  onClick={() => handleRejectReport(report.id)}
                                  className="text-orange-600 hover:text-orange-800 p-1"
                                  title="Unpublish Report"
                                >
                                  <XCircle className="w-5 h-5" />
                                </button>
                              )}

                              {report.locked && (
                                <button
                                  onClick={() => handleUnlockReport(report.id)}
                                  className="text-orange-600 hover:text-orange-800 p-1"
                                  title="Unlock Report"
                                >
                                  <Unlock className="w-5 h-5" />
                                </button>
                              )}

                              <button
                                onClick={() => handleDeleteReport(report.id)}
                                className="text-red-600 hover:text-red-800 p-1"
                                title="Delete Report"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-8">
                      <FileText className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500" />
                      <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-gray-100">
                        No reports found
                      </h3>
                      <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                        {statusFilter !== 'all' ||
                        vendorFilter !== 'all' ||
                        searchTerm
                          ? 'Try adjusting your filters'
                          : 'No reports have been created yet'}
                      </p>
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>
        </div>
      )}


      {}
      {showNewProject && <NewProjectModal vendors={vendors} onSave={handleCreateProject} onClose={() => setShowNewProject(false)} />}

      {editingProject && <EditProjectModal project={editingProject} vendors={vendors} onSave={handleUpdateProject} onClose={() => setEditingProject(null)} />}

      {showNewVendor && <NewVendorModal onSave={handleCreateVendor} onClose={() => setShowNewVendor(false)} />}

      {editingVendor && <EditVendorModal vendor={editingVendor} onSave={handleUpdateVendor} onClose={() => setEditingVendor(null)} />}

      {editingReport && <EditReportModal report={editingReport} project={projects.find(p => p.id === editingReport.projectId)} onSave={handleEditReport} onClose={() => setEditingReport(null)} isAdmin={true} />}
    </div>;
};
export default AdminView;
import React, { useEffect, useState } from 'react';
import { Plus, Edit, Save, X, Lock, FileText, AlertCircle, TrendingUp, DollarSign, Eye, Trash2 } from 'lucide-react';
import API from '../apis';
import { normalizeReport } from '../utils/normalize';
import ReportExportButtons from "../components/ReportExportButtons";
import StatCard from '../components/common/StatCard';
import ProjectCard from '../components/common/ProjectCard';
import ScheduleTimeline from '../components/charts/ScheduleTimeline';
import FinancialSummary from '../components/charts/FinancialSummary';
import ScopeSummary from '../components/charts/ScopeTracker';
import IssueSummary from '../components/issues/IssueTable';
import NewReportModal from '../components/modals/NewReportModal';
import NewIssueModal from '../components/modals/NewIssueModal';
import EditIssueModal from '../components/modals/EditIssueModal';
import EditReportModal from '../components/modals/EditReportModal';

const VendorView = ({
  selectedProject,
  setSelectedProject,
  user
}) => {
  const [projects, setProjects] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [selectedReportId, setSelectedReportId] = useState(null);
  const [allReports, setAllReports] = useState([]);
  const [vendorReports, setVendorReports] = useState([]);
  const [vendorAllReports, setVendorAllReports] = useState([]);
  const [selectedTab, setSelectedTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [loadingReport, setLoadingReport] = useState(false);
  const [error, setError] = useState(null);
  const [editingReport, setEditingReport] = useState(null);
  const [editingIssue, setEditingIssue] = useState(null);
  const [showNewIssue, setShowNewIssue] = useState(false);
  const [showNewReport, setShowNewReport] = useState(false);

  const loadVendorStats = async () => {
    if (!user?.id) return;
    try {
      const statsRes = await API.get(`/reports?filters[vendor][id][$eq]=${user.id}&sort=report_month:desc&populate=*`);
      if (statsRes.data?.data) {
        const normalizedStats = statsRes.data.data.map(report => normalizeReport(report));
        setVendorAllReports(normalizedStats);
      }
    } catch (err) {
      // ignore stats error for now
    }
  };

  useEffect(() => {
    const loadVendorProjects = async () => {
      if (!user?.id) return;

      try {
        setLoading(true);
        const res = await API.get(`/projects?filters[users_permissions_user][id][$eq]=${user.id}&populate=*`);

        if (res.data?.data) {
          const normalizedProjects = res.data.data.map(project => ({
            id: project.id,
            documentId: project.documentId,
            title: project.title || `Project #${project.id}`,
            agency: project.agency || 'Unknown Agency',
            status: project.project_status || 'Active',
            description: project.description || '',
            vendor: {
              name: user.username || user.name || 'Unknown Vendor'
            }
          }));

          setProjects(normalizedProjects);
          await loadVendorStats();
        }
      } catch (err) {
        setError('Failed to load your projects.');
      } finally {
        setLoading(false);
      }
    };

    loadVendorProjects();
  }, [user]);

  useEffect(() => {
    const loadVendorProjects = async () => {
      if (!user?.id) return;

      try {
        setLoading(true);
        const res = await API.get(`/projects?filters[users_permissions_user][id][$eq]=${user.id}&populate=*`);

        if (res.data?.data) {
          const basicProjects = res.data.data.map(project => ({
            id: project.id,
            documentId: project.documentId,
            title: project.title || `Project #${project.id}`,
            agency: project.agency || 'Unknown Agency',
            status: project.project_status || 'Active',
            description: project.description || '',
            vendor: {
              name: user.username || user.name || 'Unknown Vendor'
            }
          }));

          const enrichedProjects = await Promise.all(
            basicProjects.map(async project => {
              try {
                const projectRes = await API.get(`/projects/${project.documentId}?populate=reports`);

                if (projectRes.data.data?.reports?.length > 0) {
                  const approvedReports = projectRes.data.data.reports
                    .filter(r => r.report_status === "Approved")
                    .sort((a, b) => new Date(b.report_month) - new Date(a.report_month));

                  if (approvedReports.length > 0) {
                    const reportRes = await API.get(`/reports/${approvedReports[0].id}?populate=*`);
                    const report = normalizeReport(reportRes.data.data);

                    return {
                      ...project,
                      openIssues: report.issues?.filter(i => i.status === 'Open').length || 0,
                      closedIssues: report.issues?.filter(i => i.status === 'Closed').length || 0,
                      totalScope: report.scope?.totalScope || 0,
                      completedScope: report.scope?.completedScope || 0,
                      originalContractAmount: report.financial?.originalContractAmount || 0,
                      totalPaidOut: report.financial?.totalPaidOut || 0,
                      lastReportDate: report.reportMonth,
                      hasApprovedData: true
                    };
                  }
                }

                const vendorReportsRes = await API.get(
                  `/reports?filters[project][documentId][$eq]=${project.documentId}&filters[vendor][id][$eq]=${user.id}&sort=report_month:desc&populate=*&pagination[limit]=1`
                );

                if (vendorReportsRes.data?.data?.length > 0) {
                  const report = normalizeReport(vendorReportsRes.data.data[0]);

                  return {
                    ...project,
                    openIssues: report.issues?.filter(i => i.status === 'Open').length || 0,
                    closedIssues: report.issues?.filter(i => i.status === 'Closed').length || 0,
                    totalScope: report.scope?.totalScope || 0,
                    completedScope: report.scope?.completedScope || 0,
                    originalContractAmount: report.financial?.originalContractAmount || 0,
                    totalPaidOut: report.financial?.totalPaidOut || 0,
                    lastReportDate: report.reportMonth,
                    hasApprovedData: false
                  };
                }

                return {
                  ...project,
                  openIssues: 0,
                  closedIssues: 0,
                  totalScope: 0,
                  completedScope: 0,
                  originalContractAmount: 0,
                  totalPaidOut: 0,
                  hasApprovedData: false
                };
              } catch (err) {
                return {
                  ...project,
                  openIssues: 0,
                  closedIssues: 0,
                  totalScope: 0,
                  completedScope: 0,
                  originalContractAmount: 0,
                  totalPaidOut: 0,
                  hasApprovedData: false
                };
              }
            })
          );

          setProjects(enrichedProjects);
          await loadVendorStats();
        }
      } catch (err) {
        setError('Failed to load your projects.');
      } finally {
        setLoading(false);
      }
    };

    loadVendorProjects();
  }, [user]);

  useEffect(() => {
    if (selectedProject) {
      reloadProjectData();
    } else {
      // Réinitialiser les reports quand on quitte un projet
      setAllReports([]);
      setSelectedReport(null);
      setSelectedReportId(null);
    }
  }, [selectedProject]);

  const handleReportSelection = reportId => {
    const report = allReports.find(r => r.id === parseInt(reportId));
    if (report) {
      setSelectedReport(report);
      setSelectedReportId(parseInt(reportId));
    }
  };

  const handleCreateIssue = async issueData => {
    try {
      const newIssue = {
        title: issueData.title,
        description: issueData.description,
        impact: issueData.impact || 'Medium',
        likelihood: issueData.likelihood || 'Medium',
        issue_status: 'Open',
        date_first_raised: new Date().toISOString().split('T')[0],
        Recommendation: issueData.vendorRecommendation || '',
        report: selectedReport?.id
      };

      await API.post('/issues', { data: newIssue });
      await reloadProjectData();
      await loadVendorStats();
      setShowNewIssue(false);
    } catch (err) {
      alert(`Failed to create issue: ${err.response?.data?.error?.message || err.message}`);
    }
  };

  const handleUpdateIssue = async (issueId, updates) => {
    try {
      const issueToUpdate = selectedReport?.issues?.find(issue => issue.id === issueId);
      const documentId = issueToUpdate?.documentId;

      if (!documentId) {
        alert('Cannot update issue: missing documentId');
        return;
      }

      await API.put(`/issues/${documentId}`, { data: updates });
      await reloadProjectData();
      await loadVendorStats();
      setEditingIssue(null);
    } catch (err) {
      alert(`Failed to update issue: ${err.response?.data?.error?.message || err.message}`);
    }
  };

  const handleDeleteIssue = async issueId => {
    if (window.confirm('Are you sure you want to delete this issue?')) {
      try {
        const issueToDelete = selectedReport?.issues?.find(issue => issue.id === issueId);
        const documentId = issueToDelete?.documentId;

        if (!documentId) {
          alert('Cannot delete issue: missing documentId');
          return;
        }

        await API.delete(`/issues/${documentId}`);
        await reloadProjectData();
        await loadVendorStats();
      } catch (err) {
        alert(`Failed to delete issue: ${err.response?.data?.error?.message || err.message}`);
      }
    }
  };

  const reloadProjectData = async () => {
    if (!selectedProject || !user?.id) return;

    try {
      setLoadingReport(true);
      const reportsRes = await API.get(
        `/reports?filters[project][documentId][$eq]=${selectedProject.documentId}&filters[vendor][id][$eq]=${user.id}&sort=report_month:desc&populate[financial_status]=*&populate[schedule_status]=*&populate[issues]=*&populate[project]=*&populate[vendor]=*`
      );

      if (reportsRes.data?.data) {
        const normalizedReports = reportsRes.data.data.map(report => normalizeReport(report));
        setAllReports(normalizedReports);

        if (selectedReportId) {
          const currentReport = normalizedReports.find(r => r.id === selectedReportId);
          if (currentReport) {
            setSelectedReport(currentReport);
          } else if (normalizedReports.length > 0) {
            setSelectedReport(normalizedReports[0]);
            setSelectedReportId(normalizedReports[0].id);
          }
        } else if (normalizedReports.length > 0) {
          // Sélectionner automatiquement le premier report si aucun n'est sélectionné
          setSelectedReport(normalizedReports[0]);
          setSelectedReportId(normalizedReports[0].id);
        }
      }
    } catch (err) {
      // ignore
    } finally {
      setLoadingReport(false);
    }
  };

  const handleCreateReport = async reportData => {
    try {
      const newReport = {
        report_month: reportData.month,
        summary: reportData.summary || '',
        locked: false,
        project: selectedProject.id,
        vendor: user.id
      };

      const reportResponse = await API.post('/reports', { data: newReport });
      const createdReport = reportResponse.data.data;

      const scheduleStatusData = {
        baseline_start: reportData.schedule?.baselineStart || null,
        baseline_end: reportData.schedule?.baselineEnd || null,
        current_start: reportData.schedule?.currentStart || null,
        current_end: reportData.schedule?.currentEnd || null,
        variance_days: reportData.schedule?.variance || 0,
        schedule_notes: reportData.schedule?.notes || '',
        deliverables_commited: reportData.scope?.total || 0,
        deliverables_completed: reportData.scope?.completed || 0,
        percent_complete:
          reportData.scope?.total > 0
            ? Math.round((reportData.scope?.completed || 0) / reportData.scope.total * 100)
            : 0,
        scope_notes: reportData.scope?.notes || '',
        report: createdReport.id
      };

      await API.post('/schedule-statuses', { data: scheduleStatusData });

      if (reportData.financial) {
        const financialStatusData = {
          original_award_amount: reportData.financial.originalAmount || 0,
          total_paid_to_date: reportData.financial.paidToDate || 0,
          flag_over_budget: reportData.financial.overBudget || false,
          notes: reportData.financial.notes || '',
          report: createdReport.id
        };

        await API.post('/financial-statuses', { data: financialStatusData });
      }

      await reloadProjectData();
      await loadVendorStats();
      setShowNewReport(false);
      setSelectedReportId(createdReport.id);
      alert('✅ Report created successfully as draft!\nYou can now edit it and submit it when ready.');
    } catch (err) {
      alert('Failed to create report');
    }
  };

  const handleUpdateReport = async (reportId, updates) => {
    try {
      const reportToUpdate = allReports?.find(report => report.id === reportId);
      const documentId = reportToUpdate?.documentId;

      if (!documentId) {
        alert('Cannot update report: missing documentId');
        return;
      }

      const reportUpdates = {};
      if (updates.month !== undefined) reportUpdates.report_month = updates.month;
      if (updates.summary !== undefined) reportUpdates.summary = updates.summary;

      if (Object.keys(reportUpdates).length > 0) {
        await API.put(`/reports/${documentId}`, { data: reportUpdates });
      }

      if (updates.financial || updates.scope || updates.schedule) {
        const scheduleDocumentId = reportToUpdate?.schedule?.documentId;

        if (scheduleDocumentId) {
          const scheduleUpdates = {};

          if (updates.schedule) {
            if (updates.schedule.baselineStart !== undefined) scheduleUpdates.baseline_start = updates.schedule.baselineStart;
            if (updates.schedule.baselineEnd !== undefined) scheduleUpdates.baseline_end = updates.schedule.baselineEnd;
            if (updates.schedule.currentStart !== undefined) scheduleUpdates.current_start = updates.schedule.currentStart;
            if (updates.schedule.currentEnd !== undefined) scheduleUpdates.current_end = updates.schedule.currentEnd;
            if (updates.schedule.variance !== undefined) scheduleUpdates.variance_days = updates.schedule.variance;
            if (updates.schedule.notes !== undefined) scheduleUpdates.schedule_notes = updates.schedule.notes;
          }

          if (updates.scope) {
            if (updates.scope.total !== undefined) scheduleUpdates.deliverables_commited = updates.scope.total;
            if (updates.scope.completed !== undefined) scheduleUpdates.deliverables_completed = updates.scope.completed;
            if (updates.scope.notes !== undefined) scheduleUpdates.scope_notes = updates.scope.notes;

            if (updates.scope.total !== undefined && updates.scope.completed !== undefined) {
              scheduleUpdates.percent_complete =
                updates.scope.total > 0 ? Math.round(updates.scope.completed / updates.scope.total * 100) : 0;
            }
          }

          if (Object.keys(scheduleUpdates).length > 0) {
            await API.put(`/schedule-statuses/${scheduleDocumentId}`, { data: scheduleUpdates });
          }
        }
      }

      if (updates.financial) {
        const financialDocumentId = reportToUpdate?.financial?.documentId;

        if (financialDocumentId) {
          const financialUpdates = {
            original_award_amount: updates.financial.originalAmount,
            total_paid_to_date: updates.financial.paidToDate,
            flag_over_budget: updates.financial.overBudget,
            notes: updates.financial.notes
          };

          if (Object.keys(financialUpdates).length > 0) {
            await API.put(`/financial-statuses/${financialDocumentId}`, { data: financialUpdates });
          }
        }
      }

      await reloadProjectData();
      await loadVendorStats();
      setEditingReport(null);
      alert('✅ Draft updated successfully!');
    } catch (err) {
      alert(`Failed to update report: ${err.response?.data?.error?.message || err.message}`);
    }
  };

  const handleLockReport = async reportId => {
    if (window.confirm('Are you sure you want to submit this report?')) {
      try {
        const reportToLock = allReports?.find(report => report.id === reportId);
        const documentId = reportToLock?.documentId;

        if (!documentId) {
          alert('Cannot submit report: missing documentId');
          return;
        }

        await API.put(`/reports/${documentId}`, {
          data: {
            report_status: "Submitted",
            locked: true
          }
        });

        await reloadProjectData();
        await loadVendorStats();
        alert('✅ Report submitted for admin approval!');
      } catch (err) {
        alert('Failed to submit report. Please try again.');
      }
    }
  };

  if (loading) {
    return <div className="p-6 text-gray-700 dark:text-gray-200">Loading vendor dashboard...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-600 dark:text-red-400">{error}</div>;
  }

  if (!user) {
    return <div className="p-6 text-gray-600 dark:text-gray-300">Please login to access the vendor dashboard.</div>;
  }

  return (
    <>
      {selectedProject ? (
        <div className="space-y-6">
          {/* Back + tabs */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSelectedProject(null)}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              ← Back to My Projects
            </button>
            <div className="flex gap-2">
              <button
                onClick={() => setSelectedTab('dashboard')}
                className={`px-4 py-2 rounded-lg font-medium ${
                  selectedTab === 'dashboard'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 dark:text-gray-200'
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => setSelectedTab('issues')}
                className={`px-4 py-2 rounded-lg font-medium ${
                  selectedTab === 'issues'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 dark:text-gray-200'
                }`}
              >
                Manage Issues
              </button>
              <button
                onClick={() => setSelectedTab('reports')}
                className={`px-4 py-2 rounded-lg font-medium ${
                  selectedTab === 'reports'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 dark:text-gray-200'
                }`}
              >
                Reports
              </button>
            </div>
          </div>

          {/* Project header card */}
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
              {selectedProject.title}
            </h1>

            <p className="text-gray-600 dark:text-gray-300">{selectedProject.agency}</p>
            <div className="flex items-center space-x-4 mt-3">
              <span className="px-3 py-1 rounded-full bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300 text-sm">
                {selectedProject.status}
              </span>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                Vendor: {selectedProject.vendor?.name}
              </span>
            </div>
          </div>

          {/* Dashboard tab */}
          {selectedTab === 'dashboard' && (
            <>
              {/* Select report dropdown */}
              {allReports.length > 1 && (
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-4 border border-gray-200 dark:border-slate-700">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                    Select Report to View:
                  </label>
                  <select
                    value={selectedReportId || ''}
                    onChange={e => handleReportSelection(e.target.value)}
                    className="w-full md:w-auto px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                  >
                    {allReports.map(report => (
                      <option key={report.id} value={report.id}>
                        {report.reportMonth
                          ? new Date(report.reportMonth).toLocaleDateString(undefined, {
                              year: 'numeric',
                              month: 'long'
                            })
                          : `Report ${report.id}`}{' '}
                        - {report.report_status === 'Draft'
                          ? '📝 Draft'
                          : report.report_status === 'Submitted'
                          ? '⏳ Submitted'
                          : report.report_status === 'Approved'
                          ? '✅ Approved'
                          : report.report_status}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {loadingReport && (
                <div className="bg-blue-100 dark:bg-slate-900 border border-blue-300 dark:border-blue-500/50 text-blue-800 dark:text-blue-100 p-4 rounded">
                  Loading report data...
                </div>
              )}

              {!loadingReport && !selectedReport && (
                <div className="bg-blue-50 dark:bg-slate-900 border border-blue-200 dark:border-blue-500/40 text-blue-800 dark:text-blue-100 p-6 rounded-lg">
                  <h4 className="font-semibold mb-2">📝 How Reports Work</h4>
                  <ul className="text-sm space-y-1 list-disc list-inside">
                    <li>
                      <strong>Draft:</strong> Reports start as drafts - you can edit them freely
                    </li>
                    <li>
                      <strong>Submit:</strong> When ready, click "Submit Report" to lock it
                    </li>
                    <li>
                      <strong>Final:</strong> Submitted reports cannot be edited but remain viewable
                    </li>
                  </ul>
                  <button
                    onClick={() => setShowNewReport(true)}
                    className="mt-3 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                  >
                    Create Your First Report
                  </button>
                </div>
              )}

              {selectedReport && (
                <>
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                        Report:{' '}
                        {selectedReport.reportMonth
                          ? new Date(selectedReport.reportMonth).toLocaleDateString(undefined, {
                              year: 'numeric',
                              month: 'long'
                            })
                          : 'Current Report'}
                      </h3>

                      <div className="flex items-center justify-between mt-1">
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            selectedReport.report_status === 'Draft'
                              ? 'bg-yellow-100 text-yellow-800'
                              : selectedReport.report_status === 'Submitted'
                              ? 'bg-blue-100 text-blue-800'
                              : selectedReport.report_status === 'Approved'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {selectedReport.report_status === 'Draft'
                            ? '📝 Draft'
                            : selectedReport.report_status === 'Submitted'
                            ? '⏳ Awaiting Approval'
                            : selectedReport.report_status === 'Approved'
                            ? '✅ Approved & Published'
                            : selectedReport.report_status}
                        </span>

                        {selectedReport.report_status === 'Draft' && !selectedReport.locked && (
                          <div className="flex gap-2">
                            <button
                              onClick={() => setEditingReport(selectedReport)}
                              className="flex items-center gap-2 bg-blue-600 text-white px-3 py-2 rounded hover:bg-blue-700"
                            >
                              <Edit className="w-4 h-4" />
                              Edit Draft
                            </button>
                            <button
                              onClick={() => handleLockReport(selectedReport.id)}
                              className="flex items-center gap-2 bg-green-600 text-white px-3 py-2 rounded hover:bg-green-700"
                            >
                              <Lock className="w-4 h-4" />
                              Submit Report
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <ReportExportButtons report={selectedReport} project={selectedProject} />

                  <div id="report-export-container" className="space-y-6 mt-4">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pdf-grid-section">
                      <ScheduleTimeline report={selectedReport} />
                      <FinancialSummary report={selectedReport} />
                    </div>

                    <ScopeSummary report={selectedReport} />
                    <IssueSummary issues={selectedReport?.issues || []} />
                  </div>
                </>
              )}
            </>
          )}

          {/* Issues tab */}
          {selectedTab === 'issues' && (
            <>
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Issue Management</h2>
                  {selectedReport && (
                    <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                      Issues for:{' '}
                      {selectedReport.reportMonth
                        ? new Date(selectedReport.reportMonth).toLocaleDateString(undefined, {
                            year: 'numeric',
                            month: 'long'
                          })
                        : 'Current Report'}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => setShowNewIssue(true)}
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4" />
                  Add New Issue
                </button>
              </div>

              {allReports.length > 1 && (
                <div className="bg-white dark:bg-slate-900 rounded-lg影 shadow p-4 border border-gray-200 dark:border-slate-700">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                    View Issues for Report:
                  </label>
                  <select
                    value={selectedReportId || ''}
                    onChange={e => handleReportSelection(e.target.value)}
                    className="w-full md:w-auto px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                  >
                    {allReports.map(report => (
                      <option key={report.id} value={report.id}>
                        {report.reportMonth
                          ? new Date(report.reportMonth).toLocaleDateString(undefined, {
                              year: 'numeric',
                              month: 'long'
                            })
                          : `Report ${report.id}`}{' '}
                        ({report.issues?.length || 0} issues)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 p-6">
                {selectedReport?.issues?.length > 0 ? (
                  <div className="space-y-4">
                    {selectedReport.issues.map(issue => (
                      <div
                        key={issue.id}
                        className="border border-gray-200 dark:border-slate-700 rounded-lg p-4 bg-white dark:bg-slate-900"
                      >
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-semibold text-lg text-gray-900 dark:text-gray-100">
                              {issue.title}
                            </h4>
                            <p className="text-gray-600 dark:text-gray-300 mt-1">
                              {issue.description}
                            </p>
                            <div className="flex gap-4 mt-2 text-sm">
                              <span className="text-gray-500 dark:text-gray-400">
                                Impact: {issue.impact}
                              </span>
                              <span className="text-gray-500 dark:text-gray-400">
                                Likelihood: {issue.likelihood}
                              </span>
                              <span
                                className={`px-2 py-1 rounded text-xs ${
                                  issue.status === 'Open'
                                    ? 'bg-red-100 text-red-800'
                                    : 'bg-green-100 text-green-800'
                                }`}
                              >
                                {issue.status}
                              </span>
                            </div>
                            <div className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                              Created:{' '}
                              {issue.dateFirstRaised
                                ? new Date(issue.dateFirstRaised).toLocaleDateString()
                                : 'Unknown'}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => setEditingIssue(issue)}
                              className="text-blue-600 hover:text-blue-800"
                              title="Edit Issue"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            {issue.status === 'Open' && (
                              <button
                                onClick={() => handleUpdateIssue(issue.id, { issue_status: 'Closed' })}
                                className="text-green-600 hover:text-green-800"
                                title="Mark as Resolved"
                              >
                                ✓
                              </button>
                            )}
                            <button
                              onClick={() => handleDeleteIssue(issue.id)}
                              className="text-red-600 hover:text-red-800"
                              title="Delete Issue"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-600 dark:text-gray-300 text-lg mb-2">
                      No issues found for this report
                    </p>
                    <p className="text-gray-500 dark:text-gray-400 text-sm">
                      Issues are automatically associated with the report they are created in.
                    </p>
                  </div>
                )}
              </div>
            </>
          )}

          {/* Reports tab */}
          {selectedTab === 'reports' && (
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Monthly Reports</h2>
                <button
                  onClick={() => setShowNewReport(true)}
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  <FileText className="w-4 h-4" />
                  Create New Report
                </button>
              </div>

              <div className="space-y-4">
                {allReports.length > 0 ? (
                  allReports.map(report => (
                    <div
                      key={report.id}
                      className={`border rounded-lg p-4 cursor-pointer transition-all ${
                        selectedReportId === report.id
                          ? 'ring-2 ring-blue-500 bg-blue-50 dark:bg-slate-800 border-blue-200 dark:border-blue-500/60'
                          : 'border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-gray-50 dark:hover:bg-slate-800'
                      }`}
                      onClick={() => handleReportSelection(report.id)}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-lg text-gray-900 dark:text-gray-100">
                              {report.reportMonth
                                ? new Date(report.reportMonth).toLocaleDateString(undefined, {
                                    year: 'numeric',
                                    month: 'long'
                                  })
                                : 'Report'}
                            </h3>
                            <span
                              className={`px-3 py-1 rounded-full text-sm font-medium ${
                                report.report_status === 'Draft'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : report.report_status === 'Submitted'
                                  ? 'bg-blue-100 text-blue-800'
                                  : report.report_status === 'Approved'
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {report.report_status === 'Draft'
                                ? '📝 Draft'
                                : report.report_status === 'Submitted'
                                ? '⏳ Awaiting Approval'
                                : report.report_status === 'Approved'
                                ? '✅ Approved & Published'
                                : report.report_status}
                            </span>
                          </div>

                          <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                            {report.summary || 'No summary provided'}
                          </p>

                          <div className="flex gap-4 text-xs text-gray-500 dark:text-gray-400">
                            <span>Issues: {report.issues?.length || 0}</span>
                            <span>
                              Created:{' '}
                              {report.reportMonth
                                ? new Date(report.reportMonth).toLocaleDateString()
                                : 'Unknown'}
                            </span>
                            {!report.locked && (
                              <span className="text-yellow-600 font-medium">• Editable</span>
                            )}
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              setSelectedReport(report);
                              setSelectedReportId(report.id);
                              setSelectedTab('dashboard');
                            }}
                            className="text-blue-600 hover:text-blue-800"
                            title="View Report"
                          >
                            <Eye className="w-5 h-5" />
                          </button>

                          {!report.locked && (
                            <>
                              <button
                                onClick={e => {
                                  e.stopPropagation();
                                  setEditingReport(report);
                                }}
                                className="text-blue-600 hover:text-blue-800"
                                title="Edit Draft"
                              >
                                <Edit className="w-5 h-5" />
                              </button>
                              <button
                                onClick={e => {
                                  e.stopPropagation();
                                  setSelectedReport(report);
                                  setSelectedReportId(report.id);
                                  handleLockReport(report.id);
                                }}
                                className="text-green-600 hover:text-green-800"
                                title="Submit Report (Lock)"
                              >
                                <Lock className="w-5 h-5" />
                              </button>
                            </>
                          )}

                          {report.locked && (
                            <span className="text-gray-400 dark:text-gray-500" title="Report is locked">
                              🔒
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 dark:text-gray-300 text-lg mb-2">
                      No reports found for this project yet
                    </p>
                    <p className="text-gray-500 dark:text-gray-400 text-sm">
                      Create your first monthly report to get started.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {/* Vendor dashboard hero */}
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
              Vendor Dashboard
            </h1>

            <p className="text-gray-600 dark:text-gray-300">
              Welcome, {user.username || user.email}. Manage your assigned projects and submit reports.
            </p>
          </div>

          {/* Stat cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard
              title="Active Projects"
              value={projects.length}
              icon={FileText}
              subtitle="Currently assigned"
              color="blue"
            />
            <StatCard
              title="Draft Reports"
              value={vendorAllReports.filter(r => r.report_status === "Draft").length}
              icon={Edit}
              subtitle="Need to be submitted"
              color="orange"
            />
            <StatCard
              title="Submitted Reports"
              value={vendorAllReports.filter(r => r.report_status === "Submitted").length}
              icon={Lock}
              subtitle="Final reports"
              color="green"
            />
          </div>

          {/* My Projects */}
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 p-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-4">My Projects</h2>
            {projects.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 text-gray-400 dark:text-gray-500 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-300 text-lg mb-2">
                  No projects assigned yet
                </p>
                <p className="text-gray-500 dark:text-gray-400 text-sm">
                  Contact your administrator to get assigned to projects.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {projects.map(proj => (
                  <ProjectCard
                    key={proj.documentId}
                    project={proj}
                    onClick={() => setSelectedProject(proj)}
                    selected={selectedProject?.documentId === proj.documentId}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Recent Activity */}
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow border border-gray-200 dark:border-slate-700 p-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-4">Recent Activity</h2>
            <div className="space-y-3">
              {vendorAllReports.slice(0, 5).map((report, index) => (
                <div key={report.id} className="flex items-center gap-3 text-sm">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      report.report_status === 'Draft'
                        ? 'bg-orange-500'
                        : report.report_status === 'Submitted'
                        ? 'bg-blue-500'
                        : report.report_status === 'Approved'
                        ? 'bg-green-500'
                        : 'bg-gray-500'
                    }`}
                  ></div>
                  <span className="text-gray-600 dark:text-gray-300">
                    {report.report_status === 'Draft'
                      ? 'Created draft'
                      : report.report_status === 'Submitted'
                      ? 'Submitted for approval'
                      : report.report_status === 'Approved'
                      ? 'Report approved'
                      : 'Updated'}{' '}
                    report for{' '}
                    <span className="font-medium">
                      {projects.find(p => p.id === report.projectId)?.title || 'Unknown Project'}
                    </span>
                  </span>
                  <span className="text-gray-400 dark:text-gray-500 ml-auto">
                    {report.reportMonth
                      ? new Date(report.reportMonth).toLocaleDateString()
                      : 'No date'}
                  </span>
                </div>
              ))}
              {vendorAllReports.length === 0 && (
                <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                  No recent activity
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      {showNewReport && (
        <NewReportModal
          project={selectedProject}
          onSave={handleCreateReport}
          onClose={() => setShowNewReport(false)}
        />
      )}

      {showNewIssue && (
        <NewIssueModal
          project={selectedProject}
          onSave={handleCreateIssue}
          onClose={() => setShowNewIssue(false)}
        />
      )}

      {editingIssue && (
        <EditIssueModal
          issue={editingIssue}
          onSave={handleUpdateIssue}
          onClose={() => setEditingIssue(null)}
        />
      )}

      {editingReport && (
        <EditReportModal
          report={editingReport}
          project={selectedProject}
          onSave={handleUpdateReport}
          onClose={() => setEditingReport(null)}
        />
      )}
    </>
  );
};

export default VendorView;

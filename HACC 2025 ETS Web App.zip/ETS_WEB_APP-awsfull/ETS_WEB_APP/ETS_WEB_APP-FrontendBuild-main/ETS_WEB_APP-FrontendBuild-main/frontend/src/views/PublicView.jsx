import React, { useEffect, useState } from 'react';
import { TrendingUp, DollarSign, AlertCircle, FileText } from 'lucide-react';
import API from '../apis';
import { normalizeReport } from '../utils/normalize';
import ReportExportButtons from "../components/ReportExportButtons";
import StatCard from '../components/common/StatCard';
import ProjectCard from '../components/common/ProjectCard';
import FinancialSummary from '../components/charts/FinancialSummary';
import ScopeSummary from '../components/charts/ScopeTracker';
import ScheduleTimeline from '../components/charts/ScheduleTimeline';
import IssueSummary from '../components/issues/IssueTable';
import { formatCurrency } from '../utils/formatters';
const PublicView = ({
  selectedProject,
  setSelectedProject
}) => {
  const [projects, setProjects] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [loadingReport, setLoadingReport] = useState(false);
  const [error, setError] = useState(null);
  const [availableReports, setAvailableReports] = useState([]);
  const [currentReportIndex, setCurrentReportIndex] = useState(0);
  useEffect(() => {
    const loadProjects = async () => {
      try {
        const res = await API.get('/projects?populate=*');
        if (!res.data || !res.data.data) {
          throw new Error('Invalid API response structure');
        }
        if (res.data?.data) {
          const basicProjects = res.data.data.map(project => ({
            id: project.id,
            documentId: project.documentId,
            title: project.title || `Project #${project.id}`,
            agency: project.agency || 'Unknown Agency',
            status: project.project_status || 'Active',
            description: project.description || '',
            ivvVendor: project.users_permissions_user?.username || 'Unknown Vendor'
          }));
          const enrichedProjects = await Promise.all(basicProjects.map(async project => {
            try {
              const projectRes = await API.get(`/projects/${project.documentId}?populate=reports`);
              if (projectRes.data.data?.reports?.length > 0) {
                const approvedReports = projectRes.data.data.reports.filter(r => r.report_status === "Approved").sort((a, b) => new Date(b.report_month) - new Date(a.report_month));
                if (approvedReports.length > 0) {
                  const reportRes = await API.get(`/reports/${approvedReports[0].id}?populate=*`);
                  const report = normalizeReport(reportRes.data.data);
                  return {
                    ...project,
                    openIssues: report.issues?.filter(i => i.status === 'Open').length || 0,
                    closedIssues: report.issues?.filter(i => i.status === 'Closed').length || 0,
                    totalScope: report.scope?.totalScope || 0,
                    completedScope: report.scope?.completedScope || 0,
                    originalContractAmount: report.financial?.originalContractAmount || 0,
                    totalPaidOut: report.financial?.totalPaidOut || 0,
                    lastReportDate: report.reportMonth,
                    hasApprovedData: true
                  };
                }
              }
              return {
                ...project,
                openIssues: 0,
                closedIssues: 0,
                totalScope: 0,
                completedScope: 0,
                originalContractAmount: 0,
                totalPaidOut: 0,
                hasApprovedData: false
              };
            } catch (err) {
              return {
                ...project,
                openIssues: 0,
                closedIssues: 0,
                totalScope: 0,
                completedScope: 0,
                originalContractAmount: 0,
                totalPaidOut: 0,
                hasApprovedData: false
              };
            }
          }));
          setProjects(enrichedProjects);
        }
      } catch (err) {
        setError(`Unable to load projects: ${err.message}`);
      } finally {
        setLoadingProjects(false);
      }
    };
    loadProjects();
  }, []);
  const loadReportByIndex = async index => {
    if (index < 0 || index >= availableReports.length) return;
    setLoadingReport(true);
    try {
      const reportRes = await API.get(`/reports/${availableReports[index].id}?populate=*`);
      const normalized = normalizeReport(reportRes.data.data);
      setSelectedReport(normalized);
      setCurrentReportIndex(index);
    } finally {
      setLoadingReport(false);
    }
  };
  const goToNextReport = () => {
    if (currentReportIndex < availableReports.length - 1) {
      loadReportByIndex(currentReportIndex + 1);
    }
  };
  const goToPrevReport = () => {
    if (currentReportIndex > 0) {
      loadReportByIndex(currentReportIndex - 1);
    }
  };
  useEffect(() => {
    if (!selectedProject) {
      setSelectedReport(null);
      return;
    }
    const loadReport = async () => {
      setLoadingReport(true);
      try {
        const projectRes = await API.get(`/projects/${selectedProject.documentId}?populate=reports`);
        if (projectRes.data.data?.reports?.length > 0) {
          const approvedReports = projectRes.data.data.reports.filter(r => r.report_status === "Approved").sort((a, b) => new Date(b.report_month) - new Date(a.report_month));
          if (approvedReports.length > 0) {
            setAvailableReports(approvedReports);
            setCurrentReportIndex(0);
            const reportRes = await API.get(`/reports/${approvedReports[0].id}?populate=*`);
            const normalized = normalizeReport(reportRes.data.data);
            setSelectedReport(normalized);
          } else {
            setAvailableReports([]);
            setSelectedReport(null);
          }
        } else {
          setAvailableReports([]);
          setSelectedReport(null);
        }
      } finally {
        setLoadingReport(false);
      }
    };
    loadReport();
  }, [selectedProject]);
  const handleProjectClick = project => setSelectedProject(project);
  const handleBackToList = () => {
    setSelectedProject(null);
    setSelectedReport(null);
  };
  if (loadingProjects) {
    return <div className="p-6 text-gray-500 dark:text-gray-300">Loading projects...</div>;
  }
  if (error) {
    return <div className="p-6 text-red-600 dark:text-red-400">{error}</div>;
  }
  if (selectedProject && selectedReport) {
    return <div className="space-y-6">
        <div className="flex items-center justify-between">
          <button onClick={handleBackToList} className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 font-medium">
            ← Back to All Projects
          </button>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{selectedProject.title}</h1>
          <p className="text-gray-600 dark:text-gray-300">{selectedProject.department}</p>

          <div className="flex gap-4 mt-4">
            <span className="inline-flex px-3 py-1 text-sm font-semibold rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300">
              {selectedProject.status}
            </span>
            <span className="text-sm text-gray-600 dark:text-gray-300">
              IV&V Vendor: {selectedProject.ivvVendor}
            </span>
          </div>
        </div>

        {}
        {availableReports.length > 0 && <div className="bg-white dark:bg-slate-800 rounded-lg shadow border border-gray-200 dark:border-slate-700">
            <div className="p-4 border-b border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-900">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Report Navigation</h2>
                  <span className="text-sm text-gray-600 dark:text-gray-300">
                    {availableReports.length} approved report{availableReports.length > 1 ? 's' : ''}
                  </span>
                </div>

                {availableReports.length > 1 && <div className="flex items-center gap-2">
                    <button onClick={goToPrevReport} disabled={currentReportIndex === 0} className={`px-3 py-1 rounded ${currentReportIndex === 0 ? 'bg-gray-100 dark:bg-slate-700 text-gray-400 cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600'}`}>
                      ← Previous
                    </button>

                    <span className="text-sm text-gray-600 dark:text-gray-300 px-3">
                      {currentReportIndex + 1} of {availableReports.length}
                    </span>

                    <button onClick={goToNextReport} disabled={currentReportIndex === availableReports.length - 1} className={`px-3 py-1 rounded ${currentReportIndex === availableReports.length - 1 ? 'bg-gray-100 dark:bg-slate-700 text-gray-400 cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600'}`}>
                      Next →
                    </button>
                  </div>}
              </div>

              <div className="mt-3 flex items-center gap-6 text-sm text-gray-600 dark:text-gray-300">
                <span>
                  <strong>Report Date:</strong>{' '}
                  {selectedReport?.reportMonth ? new Date(selectedReport.reportMonth).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long'
              }) : 'Unknown'}
                </span>
                <span>
                  <strong>Issues:</strong> {selectedReport?.issues?.length || 0}
                </span>
                <span className="px-2 py-1 rounded-full text-xs bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300">
                  ✓ Approved & Published
                </span>
              </div>
            </div>

            {}
            {availableReports.length > 1 && <div className="p-4 border-b border-gray-200 dark:border-slate-700">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Jump to specific report:
                </label>

                <select value={currentReportIndex} onChange={e => loadReportByIndex(parseInt(e.target.value))} className="w-full max-w-md px-3 py-2 border border-gray-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-200 focus:ring-2 focus:ring-blue-500">
                  {availableReports.map((report, index) => <option key={report.id} value={index}>
                      {new Date(report.report_month).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long'
              })}{' '}
                      {index === 0 ? '(Latest)' : ''}
                    </option>)}
                </select>
              </div>}
          </div>}

        {}
        {availableReports.length === 0 && !loadingReport && <div className="bg-white dark:bg-slate-800 rounded-lg shadow border border-gray-200 dark:border-slate-700 p-8 text-center">
            <FileText className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No Published Reports</h3>
            <p className="text-gray-600 dark:text-gray-300">
              This project doesn't have any approved reports available for public viewing yet.
            </p>
          </div>}

        {}
        {selectedReport && <>
    {}
    <ReportExportButtons report={selectedReport} project={selectedProject} />

    {}
    <div id="report-export-container" className="space-y-6 mt-4">

  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pdf-grid-section">
    <ScheduleTimeline report={selectedReport} />
    <FinancialSummary report={selectedReport} />
  </div>

  <ScopeSummary report={selectedReport} />
  <IssueSummary issues={selectedReport?.issues || []} />

        </div>

  </>}
      </div>;
  }
  return <div className="space-y-6">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          State IT Projects - IV&V Reports
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          Independent Verification and Validation reports for major state IT projects.
          Click on any project to view detailed status, financials, and issue tracking.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map(project => <ProjectCard key={project.documentId} project={project} onClick={() => handleProjectClick(project)} selected={selectedProject?.documentId === project.documentId} />)}
      </div>

      {projects.length === 0 && <div className="text-center py-12">
          <p className="text-gray-500 dark:text-gray-300">No projects found.</p>
        </div>}
    </div>;
};
export default PublicView;
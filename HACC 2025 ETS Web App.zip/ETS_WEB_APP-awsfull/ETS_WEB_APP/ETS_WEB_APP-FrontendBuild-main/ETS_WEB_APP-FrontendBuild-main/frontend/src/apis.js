import axios from "axios";
const API_BASE_URL = process.env.REACT_APP_STRAPI_URL || "http://localhost:1337/api";
export function getToken() {
  return localStorage.getItem("jwt") || sessionStorage.getItem("jwt") || null;
}
export function setToken(token, persistent = true) {
  if (persistent) localStorage.setItem("jwt", token);else sessionStorage.setItem("jwt", token);
}
export function clearToken() {
  localStorage.removeItem("jwt");
  sessionStorage.removeItem("jwt");
}
export function clearUserData() {
  clearToken();
  localStorage.removeItem('ivvUser');
  sessionStorage.removeItem('ivvUser');
}
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 15000
});
api.interceptors.request.use(config => {
  const token = getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
}, error => Promise.reject(error));
api.interceptors.response.use(response => response, error => {
  if (error.response?.status === 401) {
    clearUserData();
  }
  return Promise.reject(error.response?.data?.error?.message || error.message || "API request error");
});
const API = {
  async get(url, config = {}) {
    return api.get(url, config);
  },
  async post(url, body = {}, config = {}) {
    return api.post(url, body, config);
  },
  async put(url, body = {}, config = {}) {
    return api.put(url, body, config);
  },
  async delete(url, config = {}) {
    return api.delete(url, config);
  },
  async login(identifier, password) {
    const res = await api.post("/auth/local", {
      identifier,
      password
    });
    if (res.data && res.data.jwt) {
      setToken(res.data.jwt);
    }
    return res.data;
  },
  async logout() {
    clearUserData();
  },
  async getCurrentUser() {
    return api.get("/users/me?populate=*");
  },
  async getProjectReports(projectId, lockedOnly = false) {
    const filters = lockedOnly ? `filters[locked][$eq]=true` : `filters[locked][$ne]=null`;
    return api.get(`/reports?filters[project][id][$eq]=${projectId}&${filters}&sort=report_month:desc&populate=*`);
  },
  async getLatestLockedReport(projectId) {
    return api.get(`/reports?filters[project][id][$eq]=${projectId}&filters[locked][$eq]=true&sort=report_month:desc&pagination[limit]=1&populate=*`);
  },
  async createReport(data) {
    return api.post("/reports", {
      data
    });
  },
  async updateReport(id, data) {
    return api.put(`/reports/${id}`, {
      data
    });
  },
  async deleteReport(id) {
    return api.delete(`/reports/${id}`);
  },
  async getProjectByDocumentId(documentId) {
    return api.get(`/projects/${documentId}?populate=*`);
  },
  async getLatestLockedReportByDocumentId(documentId) {
    return api.get(`/reports?filters[project][documentId][$eq]=${documentId}&filters[locked][$eq]=true&sort=report_month:desc&pagination[limit]=1&populate=*`);
  }
};
export default API;
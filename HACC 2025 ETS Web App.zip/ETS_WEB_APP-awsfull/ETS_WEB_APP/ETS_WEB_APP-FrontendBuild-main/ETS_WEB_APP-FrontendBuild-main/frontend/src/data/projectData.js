export const projects = [{
  id: 1,
  title: "Healthcare Management System",
  department: "Department of Health",
  status: "Active",
  baselineStartDate: "2024-01-01",
  baselineEndDate: "2025-06-30",
  currentStartDate: "2024-01-01",
  currentEndDate: "2025-09-30",
  originalContractAmount: 5000000,
  totalPaidOut: 2750000,
  totalScope: 25,
  completedScope: 12,
  ivvVendor: "TechAssure IV&V",
  lastUpdated: "2024-10-15"
}, {
  id: 2,
  title: "Education Portal Modernization",
  department: "Department of Education",
  status: "Active",
  baselineStartDate: "2024-03-01",
  baselineEndDate: "2025-12-31",
  currentStartDate: "2024-03-01",
  currentEndDate: "2025-12-31",
  originalContractAmount: 3200000,
  totalPaidOut: 800000,
  totalScope: 18,
  completedScope: 5,
  ivvVendor: "Validation Partners",
  lastUpdated: "2024-10-20"
}, {
  id: 3,
  title: "Tax Processing System Upgrade",
  department: "Department of Revenue",
  status: "Active",
  baselineStartDate: "2023-09-01",
  baselineEndDate: "2025-03-31",
  currentStartDate: "2023-09-01",
  currentEndDate: "2025-08-31",
  originalContractAmount: 7500000,
  totalPaidOut: 5625000,
  totalScope: 32,
  completedScope: 24,
  ivvVendor: "TechAssure IV&V",
  lastUpdated: "2024-10-18"
}];
export const issues = [{
  id: 1,
  projectId: 1,
  description: "People be dyin because of our systems",
  impact: "High",
  likelihood: "High",
  dateFirstRaised: "2024-08-15",
  vendorRecommendation: "Stop killin folks and fix the system",
  status: "Open"
}, {
  id: 2,
  projectId: 1,
  description: "Third-party API integration delays due to vendor availability",
  impact: "Medium",
  likelihood: "Medium",
  dateFirstRaised: "2024-09-01",
  vendorRecommendation: "Establish direct communication channel with third-party vendor and set firm deadlines.",
  status: "In Progress"
}, {
  id: 3,
  projectId: 1,
  description: "Security audit identified minor vulnerabilities in authentication module",
  impact: "Low",
  likelihood: "Low",
  dateFirstRaised: "2024-07-20",
  vendorRecommendation: "Apply security patches and update authentication library to latest version.",
  status: "Closed"
}, {
  id: 4,
  projectId: 2,
  description: "Resource allocation conflicts with implementation team",
  impact: "High",
  likelihood: "Medium",
  dateFirstRaised: "2024-09-10",
  vendorRecommendation: "Request additional resources or adjust project timeline to accommodate current capacity.",
  status: "Open"
}, {
  id: 5,
  projectId: 3,
  description: "Legacy system integration more complex than anticipated",
  impact: "High",
  likelihood: "High",
  dateFirstRaised: "2024-06-01",
  vendorRecommendation: "Allocate specialist resources for legacy system analysis and create detailed integration plan.",
  status: "In Progress"
}];
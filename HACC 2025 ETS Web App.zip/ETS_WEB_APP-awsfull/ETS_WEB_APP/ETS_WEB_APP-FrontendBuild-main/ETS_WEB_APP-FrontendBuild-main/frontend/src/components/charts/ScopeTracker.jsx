import React from 'react';
import { TrendingUp } from 'lucide-react';

const ScopeSummary = ({ report }) => {
  const totalScope = report.scope.totalScope || 0;
  const completedScope = report.scope.completedScope || 0;
  const percentComplete = totalScope > 0 ? (completedScope / totalScope) * 100 : 0;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700">
      <h3 className="text-lg font-semibold mb-4 flex items-center text-gray-900 dark:text-slate-100">
        <TrendingUp className="w-5 h-5 mr-2 text-purple-600" />
        Scope Completion
      </h3>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-3xl font-bold text-purple-600">
              {isNaN(percentComplete) ? '0' : percentComplete.toFixed(0)}%
            </p>
            <p className="text-sm text-gray-600 dark:text-slate-300 mt-1">
              {completedScope} of {totalScope} deliverables completed
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600 dark:text-slate-300">Remaining</p>
            <p className="text-2xl font-semibold text-gray-900 dark:text-slate-100">
              {Math.max(0, totalScope - completedScope)}
            </p>
          </div>
        </div>

        {/* Progress bar */}
        {totalScope > 0 && (
          <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-3">
            <div
              className="bg-purple-600 h-3 rounded-full transition-all duration-500"
              style={{
                width: `${Math.min(100, Math.max(0, percentComplete))}%`,
              }}
            />
          </div>
        )}

        {totalScope === 0 && (
          <div className="text-center py-4 text-gray-500 dark:text-slate-400">
            No scope data available
          </div>
        )}

        {report.scope.notes && (
          <div className="mt-4 p-3 bg-gray-50 dark:bg-slate-900/60 rounded">
            <p className="text-sm text-gray-700 dark:text-slate-100">
              {report.scope.notes}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ScopeSummary;

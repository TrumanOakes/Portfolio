import React from "react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import htmlDocx from "html-docx-js/dist/html-docx";
import { FileDown, FileText } from "lucide-react";
import html2pdf from "html2pdf.js";

const ReportExportButtons = ({
  report,
  project,
  compact = false
}) => {
  if (!report || !project) return null;

  const elementId = "report-export-container";

  const exportPDF = () => {
    const element = document.getElementById("report-export-container");
    if (!element) return alert("Report container not found.");

    document.body.classList.add("pdf-mode");

    const options = {
      filename: `${project.title.replace(/\s+/g, "_")}_Report_${report.reportMonth}.pdf`,
      html2canvas: {
        scale: 2,
        useCORS: true
      },
      jsPDF: {
        unit: "pt",
        format: "a4",
        orientation: "portrait"
      }
    };

    html2pdf()
      .set(options)
      .from(element)
      .save()
      .then(() => {
        document.body.classList.remove("pdf-mode");
      });
  };

  const exportWord = () => {
    const p = project;
    const r = report;

    const remainingMoney =
      p.originalContractAmount && p.totalPaidOut
        ? p.originalContractAmount - p.totalPaidOut
        : 0;

    const scopeRemaining =
      r.scope?.totalScope && r.scope?.completedScope
        ? r.scope.totalScope - r.scope.completedScope
        : 0;

    const htmlContent = `
  <html>
    <head>
      <meta charset="utf-8" />
      <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        h1, h2 { border-bottom: 2px solid #444; padding-bottom: 4px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 8px; border: 1px solid #ccc; }
        th { background: #eee; text-align: left; }
        .section { margin-top: 30px; }
      </style>
    </head>
    <body>

      <h1>${p.title}</h1>
      <p><strong>Agency:</strong> ${p.agency || "N/A"}</p>
      <p><strong>Vendor:</strong> ${p.ivvVendor || "N/A"}</p>
      <p><strong>Report Month:</strong> ${r.reportMonth || p.lastReportDate}</p>

      <div class="section">
        <h2>Schedule Status</h2>
        <p><strong>Baseline Start:</strong> ${r.schedule?.baselineStart || "N/A"}</p>
        <p><strong>Baseline End:</strong> ${r.schedule?.baselineEnd || "N/A"}</p>
        <p><strong>Current Start:</strong> ${r.schedule?.currentStart || "N/A"}</p>
        <p><strong>Current End:</strong> ${r.schedule?.currentEnd || "N/A"}</p>
        <p><strong>Variance (days):</strong> ${r.schedule?.varianceDays ?? "N/A"}</p>
      </div>

      <div class="section">
        <h2>Financial Summary</h2>
        <p><strong>Contract Amount:</strong> $${p.originalContractAmount}</p>
        <p><strong>Total Paid Out:</strong> $${p.totalPaidOut}</p>
        <p><strong>Remaining:</strong> $${remainingMoney}</p>
        <p><strong>Progress:</strong> 
          ${p.originalContractAmount ? Math.round(p.totalPaidOut / p.originalContractAmount * 100) : 0}%
        </p>
      </div>

      <div class="section">
        <h2>Scope Completion</h2>
        <p><strong>Completion Percentage:</strong> ${r.scope?.percentComplete || p.completedScope}%</p>
        <p>
          ${r.scope?.completedScope || p.completedScope} 
          of 
          ${r.scope?.totalScope || p.totalScope} 
          deliverables completed
        </p>
        <p><strong>Remaining:</strong> ${scopeRemaining}</p>
      </div>

      <div class="section">
        <h2>Issue Tracking</h2>
        <table>
          <tr>
            <th>Description</th>
            <th>Risk</th>
            <th>Status</th>
            <th>Recommendation</th>
          </tr>
          ${
            r.issues && r.issues.length
              ? r.issues
                  .map(
                    i => `
                <tr>
                  <td><strong>${i.title}</strong><br>${i.description}</td>
                  <td>${i.impact || "N/A"}</td>
                  <td>${i.status || "N/A"}</td>
                  <td>${i.recommendation || ""}</td>
                </tr>
              `
                  )
                  .join("")
              : `<tr><td colspan="4">No issues reported</td></tr>`
          }
        </table>
      </div>

    </body>
  </html>
  `;

    const blob = htmlDocx.asBlob(htmlContent);
    const fileName = `${p.title.replace(/\s+/g, "_")}_Report_${r.reportMonth || p.lastReportDate}.docx`;

    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    link.click();
  };

  if (compact) {
    return (
      <div className="flex gap-2">
        <button
          onClick={exportPDF}
          className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
        >
          <FileDown className="w-4 h-4" />
        </button>

        <button
          onClick={exportWord}
          className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
        >
          <FileText className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="flex gap-3 my-4">
      <button
        onClick={exportPDF}
        className="flex items-center gap-2 bg-gray-800 text-white px-4 py-2 rounded-lg hover:bg-black"
      >
        <FileDown className="w-4 h-4" />
        Export PDF
      </button>

      <button
        onClick={exportWord}
        className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
      >
        <FileText className="w-4 h-4" />
        Export Word
      </button>
    </div>
  );
};

export default ReportExportButtons;

import React, { useState } from 'react';
import { X, Save, Calendar, DollarSign, Target, Clock } from 'lucide-react';

const NewReportModal = ({
  onSave,
  onClose,
  project
}) => {
  const [reportData, setReportData] = useState({
    month: new Date().toISOString().slice(0, 7),
    summary: '',
    financial: {
      originalAmount: 0,
      paidToDate: 0,
      overBudget: false,
      notes: ''
    },
    scope: {
      total: 0,
      completed: 0,
      notes: ''
    },
    schedule: {
      baselineStart: '',
      baselineEnd: '',
      currentStart: '',
      currentEnd: '',
      variance: 0,
      notes: ''
    }
  });

  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const validateForm = () => {
    const newErrors = {};

    if (!reportData.month) {
      newErrors.month = 'Report month is required';
    }
    if (!reportData.summary.trim()) {
      newErrors.summary = 'Summary is required';
    }
    if (reportData.financial.originalAmount < 0) {
      newErrors.originalAmount = 'Amount cannot be negative';
    }
    if (reportData.scope.total < 0 || reportData.scope.completed < 0) {
      newErrors.scope = 'Deliverables cannot be negative';
    }
    if (reportData.scope.completed > reportData.scope.total) {
      newErrors.scope = 'Completed deliverables cannot exceed total';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }

    setSaving(true);
    try {
      await onSave(reportData);
    } catch (error) {
      alert('Failed to save report. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const updateFinancial = (field, value) => {
    setReportData(prev => ({
      ...prev,
      financial: {
        ...prev.financial,
        [field]: value
      }
    }));
  };

  const updateScope = (field, value) => {
    setReportData(prev => ({
      ...prev,
      scope: {
        ...prev.scope,
        [field]: value
      }
    }));
  };

  const updateSchedule = (field, value) => {
    setReportData(prev => ({
      ...prev,
      schedule: {
        ...prev.schedule,
        [field]: value
      }
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-900 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-slate-700 px-6 py-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              Create New Report
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-200"
              disabled={saving}
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <p className="text-gray-600 dark:text-gray-300 mt-1">
            Project: {project?.title}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          {/* Month */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Report Month *
              </label>
              <input
                type="month"
                value={reportData.month}
                onChange={e =>
                  setReportData(prev => ({
                    ...prev,
                    month: e.target.value
                  }))
                }
                className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                required
              />
              {errors.month && (
                <p className="text-red-600 text-xs mt-1">{errors.month}</p>
              )}
            </div>
          </div>

          {/* Summary */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
              Executive Summary *
            </label>
            <textarea
              value={reportData.summary}
              onChange={e =>
                setReportData(prev => ({
                  ...prev,
                  summary: e.target.value
                }))
              }
              className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
              rows={4}
              placeholder="Provide a high-level summary of project status, key achievements, and concerns..."
              required
            />
            {errors.summary && (
              <p className="text-red-600 text-xs mt-1">{errors.summary}</p>
            )}
          </div>

          {/* Financial */}
          <div className="border border-gray-200 dark:border-slate-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center">
              <DollarSign className="w-5 h-5 mr-2 text-green-600" />
              Financial Status
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Original Award Amount ($)
                </label>
                <input
                  type="number"
                  value={reportData.financial.originalAmount}
                  onChange={e =>
                    updateFinancial(
                      'originalAmount',
                      parseFloat(e.target.value) || 0
                    )
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                  min="0"
                  step="0.01"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Total Paid to Date ($)
                </label>
                <input
                  type="number"
                  value={reportData.financial.paidToDate}
                  onChange={e =>
                    updateFinancial(
                      'paidToDate',
                      parseFloat(e.target.value) || 0
                    )
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="md:col-span-2">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={reportData.financial.overBudget}
                    onChange={e =>
                      updateFinancial('overBudget', e.target.checked)
                    }
                    className="mr-2"
                  />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-200">
                    Project is over budget
                  </span>
                </label>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Financial Notes
                </label>
                <textarea
                  value={reportData.financial.notes}
                  onChange={e => updateFinancial('notes', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                  rows={3}
                  placeholder="Any financial concerns, budget variances, or explanations..."
                />
              </div>
            </div>
            {errors.originalAmount && (
              <p className="text-red-600 text-xs mt-1">{errors.originalAmount}</p>
            )}
          </div>

          {/* Scope */}
          <div className="border border-gray-200 dark:border-slate-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center">
              <Target className="w-5 h-5 mr-2 text-purple-600" />
              Scope Status
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Total Deliverables Committed
                </label>
                <input
                  type="number"
                  value={reportData.scope.total}
                  onChange={e =>
                    updateScope('total', parseInt(e.target.value) || 0)
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Deliverables Completed
                </label>
                <input
                  type="number"
                  value={reportData.scope.completed}
                  onChange={e =>
                    updateScope('completed', parseInt(e.target.value) || 0)
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                  min="0"
                  max={reportData.scope.total}
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Scope Notes
                </label>
                <textarea
                  value={reportData.scope.notes}
                  onChange={e => updateScope('notes', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                  rows={3}
                  placeholder="Scope changes, deliverable status, completion details..."
                />
              </div>
            </div>
            {errors.scope && (
              <p className="text-red-600 text-xs mt-1">{errors.scope}</p>
            )}
            {reportData.scope.total > 0 && (
              <div className="mt-4 p-3 bg-gray-50 dark:bg-slate-800 rounded-lg">
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  Completion:{' '}
                  {Math.round(
                    (reportData.scope.completed / reportData.scope.total) * 100
                  )}
                  %
                </p>
              </div>
            )}
          </div>

          {/* Schedule */}
          <div className="border border-gray-200 dark:border-slate-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center">
              <Clock className="w-5 h-5 mr-2 text-blue-600" />
              Schedule Status
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Baseline Start Date
                </label>
                <input
                  type="date"
                  value={reportData.schedule.baselineStart}
                  onChange={e =>
                    updateSchedule('baselineStart', e.target.value)
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Baseline End Date
                </label>
                <input
                  type="date"
                  value={reportData.schedule.baselineEnd}
                  onChange={e =>
                    updateSchedule('baselineEnd', e.target.value)
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Current Start Date
                </label>
                <input
                  type="date"
                  value={reportData.schedule.currentStart}
                  onChange={e =>
                    updateSchedule('currentStart', e.target.value)
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Current End Date
                </label>
                <input
                  type="date"
                  value={reportData.schedule.currentEnd}
                  onChange={e =>
                    updateSchedule('currentEnd', e.target.value)
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Variance (Days)
                </label>
                <input
                  type="number"
                  value={reportData.schedule.variance}
                  onChange={e =>
                    updateSchedule(
                      'variance',
                      parseInt(e.target.value) || 0
                    )
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Schedule Notes
                </label>
                <textarea
                  value={reportData.schedule.notes}
                  onChange={e => updateSchedule('notes', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100"
                  rows={3}
                  placeholder="Schedule delays, milestones, timeline adjustments..."
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-6 border-t border-gray-200 dark:border-slate-700">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 dark:text-gray-200 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800"
              disabled={saving}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
              disabled={saving}
            >
              <Save className="w-4 h-4" />
              {saving ? 'Creating...' : 'Create Report'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewReportModal;

import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Clock } from 'lucide-react';

const ScheduleTimeline = ({ report }) => {
  const parseDate = dateString => {
    if (!dateString) return null;
    try {
      const date = new Date(dateString);
      return isNaN(date.getTime()) ? null : date;
    } catch (err) {
      return null;
    }
  };

  const baselineStart = parseDate(report.schedule.baselineStart);
  const baselineEnd = parseDate(report.schedule.baselineEnd);
  const currentStart = parseDate(report.schedule.currentStart);
  const currentEnd = parseDate(report.schedule.currentEnd);

  if (!baselineStart || !baselineEnd || !currentEnd) {
    return (
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700">
        <h3 className="text-lg font-semibold mb-4 flex items-center text-gray-900 dark:text-slate-100">
          <Clock className="w-5 h-5 mr-2 text-blue-600" />
          Schedule Status
        </h3>
        <div className="text-center py-8 text-gray-500 dark:text-slate-300">
          <p>Schedule data incomplete or invalid dates</p>
        </div>
      </div>
    );
  }

  const months = [];
  let current = new Date(baselineStart);
  while (current <= currentEnd) {
    months.push({
      month: current.toLocaleDateString('en-US', {
        month: 'short',
        year: '2-digit'
      }),
      baseline: current <= baselineEnd ? 1 : 0,
      current: current <= currentEnd ? 1 : 0
    });
    current.setMonth(current.getMonth() + 2);
  }

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700">
      <h3 className="text-lg font-semibold mb-4 flex items-center text-gray-900 dark:text-slate-100">
        <Clock className="w-5 h-5 mr-2 text-blue-600" />
        Schedule Status
      </h3>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={200}>
        <LineChart data={months}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis hide />
          <Tooltip />
          <Legend />
          <Line
            type="monotone"
            dataKey="baseline"
            stroke="#6366f1"
            name="Baseline Schedule"
            strokeWidth={2}
          />
          <Line
            type="monotone"
            dataKey="current"
            stroke="#ef4444"
            name="Current Schedule"
            strokeWidth={2}
            strokeDasharray="5 5"
          />
        </LineChart>
      </ResponsiveContainer>

      {/* Dates */}
      <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
        <div>
          <p className="text-gray-600 dark:text-slate-300">Baseline End Date</p>
          <p className="font-semibold text-gray-900 dark:text-slate-100">
            {baselineEnd.toLocaleDateString()}
          </p>
        </div>
        <div>
          <p className="text-gray-600 dark:text-slate-300">Current End Date</p>
          <p className="font-semibold text-red-600">
            {currentEnd.toLocaleDateString()}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ScheduleTimeline;

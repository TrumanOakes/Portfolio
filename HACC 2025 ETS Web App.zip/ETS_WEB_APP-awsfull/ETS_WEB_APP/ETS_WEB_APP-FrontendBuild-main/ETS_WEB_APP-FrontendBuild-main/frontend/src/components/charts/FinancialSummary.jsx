import React from 'react';
import { DollarSign } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

const FinancialSummary = ({ report }) => {
  const percentPaid =
    (report.financial.totalPaidOut /
      report.financial.originalContractAmount) *
    100;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700">
      <h3 className="text-lg font-semibold mb-4 flex items-center text-gray-900 dark:text-slate-100">
        <DollarSign className="w-5 h-5 mr-2 text-green-600" />
        Financial Summary
      </h3>
      <div className="space-y-4">
        <div>
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-600 dark:text-slate-300">
              Contract Amount
            </span>
            <span className="font-semibold text-gray-900 dark:text-slate-100">
              {formatCurrency(report.financial.originalContractAmount)}
            </span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-600 dark:text-slate-300">
              Total Paid Out
            </span>
            <span className="font-semibold text-green-600">
              {formatCurrency(report.financial.totalPaidOut)}
            </span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-600 dark:text-slate-300">
              Remaining
            </span>
            <span className="font-semibold text-gray-900 dark:text-slate-100">
              {formatCurrency(
                report.financial.originalContractAmount -
                  report.financial.totalPaidOut
              )}
            </span>
          </div>
        </div>
        <div>
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-600 dark:text-slate-300">
              Expenditure Progress
            </span>
            <span className="font-semibold text-gray-900 dark:text-slate-100">
              {percentPaid.toFixed(1)}%
            </span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-3">
            <div
              className="bg-green-600 h-3 rounded-full transition-all duration-500"
              style={{ width: `${percentPaid}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialSummary;

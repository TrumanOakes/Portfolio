import React from 'react';
import { AlertCircle, Edit, Trash2 } from 'lucide-react';
import {
  calculateRiskRating,
  calculateAge,
  getRiskColor,
  getStatusColor
} from '../../utils/calculations';

const IssueSummary = ({ issues, editable = false }) => {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow border border-gray-200 dark:border-slate-700 overflow-hidden">
      <div className="p-6 border-b border-gray-200 dark:border-slate-700">
        <h3 className="text-lg font-semibold flex items-center text-gray-900 dark:text-slate-100">
          <AlertCircle className="w-5 h-5 mr-2 text-orange-600" />
          Issue Tracking
        </h3>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 dark:bg-slate-900/40">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-slate-300 uppercase tracking-wider">
                Description
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-slate-300 uppercase tracking-wider">
                Risk
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-slate-300 uppercase tracking-wider">
                Age
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-slate-300 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-slate-300 uppercase tracking-wider">
                Recommendation
              </th>
              {editable && (
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-slate-300 uppercase tracking-wider">
                  Actions
                </th>
              )}
            </tr>
          </thead>

          <tbody className="bg-white dark:bg-slate-900 divide-y divide-gray-200 dark:divide-slate-700">
            {issues.map((issue) => {
              const riskRating = calculateRiskRating(
                issue.impact,
                issue.likelihood
              );
              const age = calculateAge(issue.dateFirstRaised);

              return (
                <tr
                  key={issue.id}
                  className="hover:bg-gray-50 dark:hover:bg-slate-800"
                >
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-gray-900 dark:text-slate-100">
                      {issue.description}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-slate-400 mt-1">
                      Raised:{' '}
                      {new Date(issue.dateFirstRaised).toLocaleDateString()}
                    </p>
                  </td>

                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-1">
                      <span
                        className={`inline-flex px-2 py-1 text-xs font-semibold rounded border ${getRiskColor(
                          riskRating
                        )}`}
                      >
                        Risk: {riskRating}
                      </span>
                      <span className="text-xs text-gray-500 dark:text-slate-400">
                        I: {issue.impact}
                      </span>
                      <span className="text-xs text-gray-500 dark:text-slate-400">
                        L: {issue.likelihood}
                      </span>
                    </div>
                  </td>

                  <td className="px-6 py-4">
                    <span className="text-sm font-medium text-gray-900 dark:text-slate-100">
                      {age} days
                    </span>
                  </td>

                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${getStatusColor(
                        issue.status
                      )}`}
                    >
                      {issue.status}
                    </span>
                  </td>

                  <td className="px-6 py-4">
                    <p className="text-sm text-gray-700 dark:text-slate-200">
                      {issue.vendorRecommendation}
                    </p>
                  </td>

                  {editable && (
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button className="text-blue-600 hover:text-blue-800">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="text-red-600 hover:text-red-800">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default IssueSummary;

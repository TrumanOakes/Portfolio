import React, { useState, useEffect } from 'react';
import { X, Save, Lock, Unlock, AlertTriangle } from 'lucide-react';

const EditReportModal = ({
  report,
  project,
  onSave,
  onClose,
  isAdmin = false
}) => {
  const [formData, setFormData] = useState({
    month: '',
    summary: '',
    financial: {
      originalAmount: 0,
      paidToDate: 0,
      overBudget: false,
      notes: ''
    },
    scope: {
      total: 0,
      completed: 0,
      notes: ''
    },
    schedule: {
      baselineStart: '',
      baselineEnd: '',
      currentStart: '',
      currentEnd: '',
      variance: 0,
      notes: ''
    }
  });

  const [canEdit, setCanEdit] = useState(false);

  useEffect(() => {
    if (report) {
      setFormData({
        month: report.reportMonth || '',
        summary: report.summary || '',
        financial: {
          originalAmount: report.financial?.originalAmount || 0,
          paidToDate: report.financial?.paidToDate || 0,
          overBudget: report.financial?.overBudget || false,
          notes: report.financial?.notes || ''
        },
        scope: {
          total: report.scope?.total || 0,
          completed: report.scope?.completed || 0,
          notes: report.scope?.notes || ''
        },
        schedule: {
          baselineStart: report.schedule?.baselineStart || '',
          baselineEnd: report.schedule?.baselineEnd || '',
          currentStart: report.schedule?.currentStart || '',
          currentEnd: report.schedule?.currentEnd || '',
          variance: report.schedule?.variance || 0,
          notes: report.schedule?.notes || ''
        }
      });

      setCanEdit(isAdmin || !report.locked);
    }
  }, [report, isAdmin]);

  const handleSubmit = e => {
    e.preventDefault();
    onSave(report.id, formData);
  };

  const handleNestedChange = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-slate-900 rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b border-gray-200 dark:border-slate-700 sticky top-0 bg-white dark:bg-slate-900">
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
              {isAdmin ? 'Edit Report (Admin Override)' : 'Edit Report'}
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-300">
              {project?.title} -{' '}
              {formData.month
                ? new Date(formData.month).toLocaleDateString(undefined, {
                    year: 'numeric',
                    month: 'long'
                  })
                : 'Report'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-200"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Admin override banner */}
        {isAdmin && report?.locked && (
          <div className="mx-6 mt-4 bg-orange-50 dark:bg-orange-950 border border-orange-200 dark:border-orange-700 rounded-lg p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              <div>
                <p className="text-sm font-medium text-orange-800 dark:text-orange-200">
                  Admin Override Active
                </p>
                <p className="text-xs text-orange-700 dark:text-orange-300">
                  You are editing a submitted report. Changes will be saved
                  immediately and the vendor will see the updates.
                </p>
              </div>
            </div>
          </div>
        )}

        <form className="p-6 space-y-6" onSubmit={handleSubmit}>
          {/* Month + status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                Report Month
              </label>
              <input
                type="month"
                value={formData.month}
                onChange={e =>
                  setFormData(prev => ({
                    ...prev,
                    month: e.target.value
                  }))
                }
                disabled={!canEdit}
                className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                Status
              </label>
              <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 dark:bg-slate-800 rounded-lg">
                {report?.locked ? (
                  <>
                    <Lock className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-green-800 dark:text-green-300 font-medium">
                      Submitted (Locked)
                    </span>
                  </>
                ) : (
                  <>
                    <Unlock className="w-4 h-4 text-orange-600" />
                    <span className="text-sm text-orange-800 dark:text-orange-300 font-medium">
                      Draft (Editable)
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Summary */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
              Executive Summary
            </label>
            <textarea
              value={formData.summary}
              onChange={e =>
                setFormData(prev => ({
                  ...prev,
                  summary: e.target.value
                }))
              }
              disabled={!canEdit}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
              placeholder="Provide an executive summary of the project status..."
            />
          </div>

          {/* Financial */}
          <div className="border border-gray-200 dark:border-slate-700 rounded-lg p-4 bg-white dark:bg-slate-900">
            <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-gray-100">
              Financial Status
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                  Original Award Amount ($)
                </label>
                <input
                  type="number"
                  value={formData.financial.originalAmount}
                  onChange={e =>
                    handleNestedChange(
                      'financial',
                      'originalAmount',
                      parseFloat(e.target.value) || 0
                    )
                  }
                  disabled={!canEdit}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                  Total Paid to Date ($)
                </label>
                <input
                  type="number"
                  value={formData.financial.paidToDate}
                  onChange={e =>
                    handleNestedChange(
                      'financial',
                      'paidToDate',
                      parseFloat(e.target.value) || 0
                    )
                  }
                  disabled={!canEdit}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                />
              </div>
            </div>
            <div className="mt-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.financial.overBudget}
                  onChange={e =>
                    handleNestedChange(
                      'financial',
                      'overBudget',
                      e.target.checked
                    )
                  }
                  disabled={!canEdit}
                  className="mr-2 disabled:opacity-50"
                />
                <span className="text-sm text-gray-700 dark:text-gray-200">
                  Project is over budget
                </span>
              </label>
            </div>
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                Financial Notes
              </label>
              <textarea
                value={formData.financial.notes}
                onChange={e =>
                  handleNestedChange('financial', 'notes', e.target.value)
                }
                disabled={!canEdit}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                placeholder="Add any financial notes or concerns..."
              />
            </div>
          </div>

          {/* Scope */}
          <div className="border border-gray-200 dark:border-slate-700 rounded-lg p-4 bg-white dark:bg-slate-900">
            <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-gray-100">
              Scope Status
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                  Total Deliverables
                </label>
                <input
                  type="number"
                  value={formData.scope.total}
                  onChange={e =>
                    handleNestedChange(
                      'scope',
                      'total',
                      parseInt(e.target.value) || 0
                    )
                  }
                  disabled={!canEdit}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                  Completed Deliverables
                </label>
                <input
                  type="number"
                  value={formData.scope.completed}
                  onChange={e =>
                    handleNestedChange(
                      'scope',
                      'completed',
                      parseInt(e.target.value) || 0
                    )
                  }
                  disabled={!canEdit}
                  max={formData.scope.total}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                />
              </div>
            </div>

            <div className="mt-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-200">
                  Progress
                </span>
                <span className="text-sm text-gray-600 dark:text-gray-300">
                  {formData.scope.total > 0
                    ? Math.round(
                        (formData.scope.completed / formData.scope.total) * 100
                      )
                    : 0}
                  %
                </span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${
                      formData.scope.total > 0
                        ? Math.min(
                            (formData.scope.completed / formData.scope.total) *
                              100,
                            100
                          )
                        : 0
                    }%`
                  }}
                ></div>
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                Scope Notes
              </label>
              <textarea
                value={formData.scope.notes}
                onChange={e =>
                  handleNestedChange('scope', 'notes', e.target.value)
                }
                disabled={!canEdit}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                placeholder="Add any scope-related notes or changes..."
              />
            </div>
          </div>

          {/* Schedule */}
          <div className="border border-gray-200 dark:border-slate-700 rounded-lg p-4 bg-white dark:bg-slate-900">
            <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-gray-100">
              Schedule Status
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Baseline */}
              <div>
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-200 mb-3">
                  Baseline Schedule
                </h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-600 dark:text-gray-300 mb-1">
                      Baseline Start Date
                    </label>
                    <input
                      type="date"
                      value={formData.schedule.baselineStart}
                      onChange={e =>
                        handleNestedChange(
                          'schedule',
                          'baselineStart',
                          e.target.value
                        )
                      }
                      disabled={!canEdit}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 dark:text-gray-300 mb-1">
                      Baseline End Date
                    </label>
                    <input
                      type="date"
                      value={formData.schedule.baselineEnd}
                      onChange={e =>
                        handleNestedChange(
                          'schedule',
                          'baselineEnd',
                          e.target.value
                        )
                      }
                      disabled={!canEdit}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                    />
                  </div>
                </div>
              </div>

              {/* Current */}
              <div>
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-200 mb-3">
                  Current Schedule
                </h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-600 dark:text-gray-300 mb-1">
                      Current Start Date
                    </label>
                    <input
                      type="date"
                      value={formData.schedule.currentStart}
                      onChange={e =>
                        handleNestedChange(
                          'schedule',
                          'currentStart',
                          e.target.value
                        )
                      }
                      disabled={!canEdit}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 dark:text-gray-300 mb-1">
                      Current End Date
                    </label>
                    <input
                      type="date"
                      value={formData.schedule.currentEnd}
                      onChange={e =>
                        handleNestedChange(
                          'schedule',
                          'currentEnd',
                          e.target.value
                        )
                      }
                      disabled={!canEdit}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                Schedule Variance (Days)
              </label>
              <input
                type="number"
                value={formData.schedule.variance}
                onChange={e =>
                  handleNestedChange(
                    'schedule',
                    'variance',
                    parseInt(e.target.value) || 0
                  )
                }
                disabled={!canEdit}
                className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                placeholder="Enter positive number for delays, negative for early completion"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Positive values indicate delays, negative values indicate early
                completion
              </p>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
                Schedule Notes
              </label>
              <textarea
                value={formData.schedule.notes}
                onChange={e =>
                  handleNestedChange('schedule', 'notes', e.target.value)
                }
                disabled={!canEdit}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                placeholder="Add any schedule-related notes or concerns..."
              />
            </div>
          </div>

          {/* Locked note */}
          {!canEdit && (
            <div className="bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg p-4">
              <div className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                <div>
                  <p className="text-sm font-medium text-gray-800 dark:text-gray-100">
                    Report is Locked
                  </p>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    This report has been submitted and cannot be edited.
                    {isAdmin &&
                      ' As an admin, you can still view all details but editing requires unlocking the report first.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-3 pt-6 border-t border-gray-200 dark:border-slate-700">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 dark:text-gray-200 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800"
            >
              {canEdit ? 'Cancel' : 'Close'}
            </button>

            {canEdit && (
              <button
                type="submit"
                className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
              >
                <Save className="w-4 h-4" />
                {isAdmin ? 'Save Changes (Admin)' : 'Save Changes'}
              </button>
            )}

            {isAdmin && !canEdit && (
              <div className="flex-1 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (
                      window.confirm(
                        'Unlock this report for editing? The vendor will be able to modify it again.'
                      )
                    ) {
                      onClose();
                    }
                  }}
                  className="flex-1 flex items-center justify-center gap-2 bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700"
                >
                  <Unlock className="w-4 h-4" />
                  Unlock Report
                </button>
              </div>
            )}
          </div>

          {/* Admin capabilities */}
          {isAdmin && (
            <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-700 rounded-lg p-4">
              <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-2">
                Admin Capabilities
              </h4>
              <ul className="text-xs text-blue-700 dark:text-blue-200 space-y-1">
                <li>• Edit any report, even if locked/submitted</li>
                <li>• Changes are saved immediately and visible to vendors</li>
                <li>• Can unlock reports to allow vendor editing</li>
                <li>• Can delete reports if necessary</li>
                <li>• All admin actions are logged for audit purposes</li>
              </ul>
            </div>
          )}

          {/* Report info */}
          <div className="bg-gray-50 dark:bg-slate-800 rounded-lg p-4">
            <h4 className="text-sm font-medium text-gray-800 dark:text-gray-100 mb-2">
              Report Information
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs text-gray-600 dark:text-gray-300">
              <div>
                <span className="font-medium">Project:</span>
                <br />
                {project?.title || 'Unknown'}
              </div>
              <div>
                <span className="font-medium">Vendor:</span>
                <br />
                {project?.vendor?.name || 'Unassigned'}
              </div>
              <div>
                <span className="font-medium">Status:</span>
                <br />
                {report?.locked ? 'Submitted' : 'Draft'}
              </div>
              <div>
                <span className="font-medium">Issues:</span>
                <br />
                {report?.issues?.length || 0} total
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditReportModal;

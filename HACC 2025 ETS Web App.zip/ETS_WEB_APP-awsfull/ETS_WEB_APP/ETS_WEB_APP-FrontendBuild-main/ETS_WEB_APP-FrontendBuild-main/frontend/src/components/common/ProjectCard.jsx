import React from "react";
import { AlertCircle, FileText, TrendingUp, DollarSign } from "lucide-react";
import { formatCurrency } from "../../utils/formatters";
const ProjectCard = ({
  project,
  issues = [],
  onClick,
  selected
}) => {
  if (!project) return null;
  const openIssues = project.openIssues || 0;
  const closedIssues = project.closedIssues || 0;
  const projIssues = {
    length: openIssues + closedIssues
  };
  const title = project.title || project.name || `Project #${project.id}`;
  const department = project.department || project.owner || "";
  const vendorName = project.vendor?.name || project.vendor?.companyName || project.ivvVendor || "";
  const scopePercent = project.totalScope && project.completedScope ? Math.round(project.completedScope / project.totalScope * 100) : 0;
  const budget = project.originalContractAmount != null ? project.originalContractAmount : null;
  return <button className={`w-full text-left rounded-lg border p-5 shadow-sm transition 
        bg-white dark:bg-slate-900
        ${selected ? "border-blue-500 ring-2 ring-blue-200 dark:ring-blue-500/40" : "border-gray-200 hover:shadow-md hover:border-gray-300 dark:border-slate-700 dark:hover:border-slate-500"}`} onClick={onClick}>
      {}
      <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
        {title}
      </h2>

      {}
      {department && <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
          {department}
        </p>}

      {}
      {vendorName && <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          Vendor:{" "}
          <span className="font-medium text-gray-800 dark:text-gray-100">
            {vendorName}
          </span>
        </p>}

      {}
      <div className="my-3 border-t border-gray-200 dark:border-slate-700" />

      {}
      <div className="grid grid-cols-3 gap-3 text-sm">
        {}
        <div className="flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-orange-500" />
          <div>
            <p className="font-semibold text-gray-900 dark:text-gray-100">
              {openIssues}
            </p>
            <p className="text-gray-500 dark:text-gray-400 text-xs">
              Open Issues
            </p>
          </div>
        </div>

        {}
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-purple-500" />
          <div>
            <p className="font-semibold text-gray-900 dark:text-gray-100">
              {scopePercent != null ? `${scopePercent}%` : "-"}
            </p>
            <p className="text-gray-500 dark:text-gray-400 text-xs">
              Scope
            </p>
          </div>
        </div>

        {}
        <div className="flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-green-600" />
          <div>
            <p className="font-semibold text-gray-900 dark:text-gray-100">
              {budget != null ? formatCurrency(budget) : "-"}
            </p>
            <p className="text-gray-500 dark:text-gray-400 text-xs">
              Budget
            </p>
          </div>
        </div>
      </div>

      {}
      <div className="mt-3 flex items-center text-xs text-gray-500 dark:text-gray-400">
        <FileText className="w-3 h-3 mr-1" />
        {projIssues.length} issues tracked ({closedIssues} closed)
      </div>
    </button>;
};
export default ProjectCard;
import React from "react";
const StatCard = ({
  title,
  value,
  icon: Icon,
  subtitle,
  color = "blue"
}) => <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 border border-gray-200 dark:border-slate-700 transition-colors duration-200">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-600 dark:text-gray-300">
          {title}
        </p>
        <p className={`text-2xl font-bold text-${color}-600 mt-2`}>
          {value}
        </p>
        {subtitle && <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            {subtitle}
          </p>}
      </div>
      <div className={`p-3 bg-${color}-100 rounded-lg`}>
        <Icon className={`w-6 h-6 text-${color}-600`} />
      </div>
    </div>
  </div>;
export default StatCard;
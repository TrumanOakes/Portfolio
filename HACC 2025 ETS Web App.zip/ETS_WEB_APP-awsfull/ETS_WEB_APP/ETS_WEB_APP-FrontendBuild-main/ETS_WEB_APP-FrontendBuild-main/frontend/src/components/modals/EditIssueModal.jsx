import React, { useState, useEffect } from 'react';
import { X, Save, AlertTriangle, Target, Info } from 'lucide-react';

const EditIssueModal = ({
  issue,
  onSave,
  onClose
}) => {
  const [issueData, setIssueData] = useState({
    title: '',
    description: '',
    impact: 'Medium',
    likelihood: 'Medium',
    vendorRecommendation: '',
    status: 'Open'
  });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (issue) {
      setIssueData({
        title: issue.title || '',
        description: issue.description || '',
        impact: issue.impact || 'Medium',
        likelihood: issue.likelihood || 'Medium',
        vendorRecommendation: issue.vendorRecommendation || '',
        status: issue.status || 'Open'
      });
    }
  }, [issue]);

  const impactOptions = [
    {
      value: 'Low',
      label: 'Low',
      color: 'text-green-600',
      description: 'Minor impact on project'
    },
    {
      value: 'Medium',
      label: 'Medium',
      color: 'text-yellow-600',
      description: 'Moderate impact on project'
    },
    {
      value: 'High',
      label: 'High',
      color: 'text-red-600',
      description: 'Significant impact on project'
    }
  ];

  const likelihoodOptions = [
    {
      value: 'Low',
      label: 'Low',
      color: 'text-green-600',
      description: 'Unlikely to occur'
    },
    {
      value: 'Medium',
      label: 'Medium',
      color: 'text-yellow-600',
      description: 'May occur'
    },
    {
      value: 'High',
      label: 'High',
      color: 'text-red-600',
      description: 'Likely to occur'
    }
  ];

  const statusOptions = [
    {
      value: 'Open',
      label: 'Open',
      color: 'text-red-600',
      description: 'Issue is active and needs attention'
    },
    {
      value: 'In Progress',
      label: 'In Progress',
      color: 'text-yellow-600',
      description: 'Issue is being worked on'
    },
    {
      value: 'Resolved',
      label: 'Resolved',
      color: 'text-green-600',
      description: 'Issue has been fixed'
    },
    {
      value: 'Closed',
      label: 'Closed',
      color: 'text-gray-600',
      description: 'Issue is closed and archived'
    }
  ];

  const validateForm = () => {
    const newErrors = {};

    if (!issueData.title.trim()) {
      newErrors.title = 'Issue title is required';
    } else if (issueData.title.trim().length < 5) {
      newErrors.title = 'Title must be at least 5 characters';
    }

    if (!issueData.description.trim()) {
      newErrors.description = 'Issue description is required';
    } else if (issueData.description.trim().length < 20) {
      newErrors.description = 'Description must be at least 20 characters';
    }

    if (!issueData.vendorRecommendation.trim()) {
      newErrors.vendorRecommendation = 'Vendor recommendation is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async e => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setSaving(true);
    try {
      await onSave(issue.id, {
        title: issueData.title,
        description: issueData.description,
        impact: issueData.impact,
        likelihood: issueData.likelihood,
        Recommendation: issueData.vendorRecommendation,
        issue_status: issueData.status
      });
    } catch (error) {
      alert('Failed to save issue. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const getRiskLevel = () => {
    const impactScore = impactOptions.findIndex(opt => opt.value === issueData.impact) + 1;
    const likelihoodScore = likelihoodOptions.findIndex(opt => opt.value === issueData.likelihood) + 1;
    const riskScore = impactScore * likelihoodScore;

    if (riskScore <= 2) {
      return {
        level: 'Low',
        color: 'bg-green-100 text-green-800',
        score: riskScore
      };
    }

    if (riskScore <= 6) {
      return {
        level: 'Medium',
        color: 'bg-yellow-100 text-yellow-800',
        score: riskScore
      };
    }

    return {
      level: 'High',
      color: 'bg-red-100 text-red-800',
      score: riskScore
    };
  };

  const riskLevel = getRiskLevel();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-900 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-slate-700 px-6 py-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 flex items-center">
              <AlertTriangle className="w-6 h-6 mr-2 text-orange-600" />
              Edit Issue
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-200"
              disabled={saving}
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <p className="text-gray-600 dark:text-gray-300 mt-1">
            Issue ID: {issue?.id}
          </p>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Created:{' '}
            {issue?.dateFirstRaised
              ? new Date(issue.dateFirstRaised).toLocaleDateString()
              : 'Unknown'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Basic fields */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                Issue Title *
              </label>
              <input
                type="text"
                value={issueData.title}
                onChange={e =>
                  setIssueData(prev => ({
                    ...prev,
                    title: e.target.value
                  }))
                }
                className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Brief, descriptive title of the issue..."
                required
              />
              {errors.title && (
                <p className="text-red-600 text-xs mt-1">{errors.title}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                Issue Status
              </label>
              <div className="space-y-2">
                {statusOptions.map(option => (
                  <label key={option.value} className="flex items-center">
                    <input
                      type="radio"
                      name="status"
                      value={option.value}
                      checked={issueData.status === option.value}
                      onChange={e =>
                        setIssueData(prev => ({
                          ...prev,
                          status: e.target.value
                        }))
                      }
                      className="mr-2"
                    />
                    <span className={`font-medium ${option.color}`}>
                      {option.label}
                    </span>
                    <span className="text-gray-500 dark:text-gray-400 text-sm ml-2">
                      - {option.description}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                Detailed Description *
              </label>
              <textarea
                value={issueData.description}
                onChange={e =>
                  setIssueData(prev => ({
                    ...prev,
                    description: e.target.value
                  }))
                }
                className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={5}
                placeholder="Provide a detailed description of the issue..."
                required
              />
              {errors.description && (
                <p className="text-red-600 text-xs mt-1">
                  {errors.description}
                </p>
              )}
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {issueData.description.length}/500 characters
              </p>
            </div>
          </div>

          {/* Risk assessment */}
          <div className="border border-gray-200 dark:border-slate-700 rounded-lg p-4 bg-white dark:bg-slate-900">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center">
              <Target className="w-5 h-5 mr-2 text-red-600" />
              Risk Assessment
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Impact Level
                </label>
                <div className="space-y-2">
                  {impactOptions.map(option => (
                    <label key={option.value} className="flex items-center">
                      <input
                        type="radio"
                        name="impact"
                        value={option.value}
                        checked={issueData.impact === option.value}
                        onChange={e =>
                          setIssueData(prev => ({
                            ...prev,
                            impact: e.target.value
                          }))
                        }
                        className="mr-2"
                      />
                      <span className={`font-medium ${option.color}`}>
                        {option.label}
                      </span>
                      <span className="text-gray-500 dark:text-gray-400 text-sm ml-2">
                        - {option.description}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                  Likelihood
                </label>
                <div className="space-y-2">
                  {likelihoodOptions.map(option => (
                    <label key={option.value} className="flex items-center">
                      <input
                        type="radio"
                        name="likelihood"
                        value={option.value}
                        checked={issueData.likelihood === option.value}
                        onChange={e =>
                          setIssueData(prev => ({
                            ...prev,
                            likelihood: e.target.value
                          }))
                        }
                        className="mr-2"
                      />
                      <span className={`font-medium ${option.color}`}>
                        {option.label}
                      </span>
                      <span className="text-gray-500 dark:text-gray-400 text-sm ml-2">
                        - {option.description}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 bg-gray-50 dark:bg-slate-800 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-200">
                  Calculated Risk Level:
                </span>
                <span
                  className={`px-3 py-1 rounded-full text-sm font-medium ${riskLevel.color}`}
                >
                  {riskLevel.level} Risk (Score: {riskLevel.score}/9)
                </span>
              </div>
            </div>
          </div>

          {/* Vendor recommendation */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
              Vendor Recommendation *
            </label>
            <textarea
              value={issueData.vendorRecommendation}
              onChange={e =>
                setIssueData(prev => ({
                  ...prev,
                  vendorRecommendation: e.target.value
                }))
              }
              className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={4}
              placeholder="Provide your professional recommendation for addressing this issue..."
              required
            />
            {errors.vendorRecommendation && (
              <p className="text-red-600 text-xs mt-1">
                {errors.vendorRecommendation}
              </p>
            )}
          </div>

          {/* Status change notice */}
          {issueData.status !== issue?.status && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start">
                <Info className="w-5 h-5 text-yellow-600 mt-0.5 mr-2 flex-shrink-0" />
                <div className="text-sm text-yellow-800">
                  <p className="font-medium">Status Change Detected</p>
                  <p>
                    Changing from{' '}
                    <span className="font-medium">{issue?.status}</span> to{' '}
                    <span className="font-medium">{issueData.status}</span>
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-6 border-t border-gray-200 dark:border-slate-700">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 dark:text-gray-200 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800"
              disabled={saving}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
              disabled={saving}
            >
              <Save className="w-4 h-4" />
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditIssueModal;

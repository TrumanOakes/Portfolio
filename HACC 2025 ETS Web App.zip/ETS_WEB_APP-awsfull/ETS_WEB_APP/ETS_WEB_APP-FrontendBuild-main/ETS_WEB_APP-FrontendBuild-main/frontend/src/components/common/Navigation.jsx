import React, { useState, useEffect } from "react";

const Navigation = ({
  currentView,
  setCurrentView,
  setSelectedProject,
  user,
  onLogout,
  onLoginClick
}) => {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [textSize, setTextSize] = useState("base");

  const handleViewChange = (view) => {
    setCurrentView(view);
    setSelectedProject(null);
  };

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [darkMode]);

  useEffect(() => {
    let scale = 1;
    if (textSize === "lg") scale = 1.125;
    if (textSize === "xl") scale = 1.25;
    document.documentElement.style.setProperty("--app-font-scale", String(scale));
  }, [textSize]);

  return (
    <nav className="bg-white dark:bg-slate-900 shadow-sm border-b border-gray-200 dark:border-slate-700 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 relative">
          {/* LEFT SIDE: logo + title */}
          <div className="flex items-center">
            <img
              src="/ETS_logo.png"
              alt="ETS IV&V Portal logo"
              className="h-8 w-auto"
            />
            <span className="ml-2 text-xl font-bold text-gray-900 dark:text-slate-100">
              ETS IV&V Portal
            </span>
          </div>

          {/* RIGHT SIDE: nav buttons, settings, user menu */}
          <div className="flex items-center space-x-4">
            {/* Public view */}
            <button
              onClick={() => handleViewChange("public")}
              className={`px-4 py-2 rounded-lg font-medium ${
                currentView === "public"
                  ? "bg-blue-600 text-white"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              Public View
            </button>

            {/* Vendor portal */}
            {user && (user.role === "vendor" || user.role === "admin") && (
              <button
                onClick={() => handleViewChange("vendor")}
                className={`px-4 py-2 rounded-lg font-medium ${
                  currentView === "vendor"
                    ? "bg-blue-600 text-white"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                Vendor Portal
              </button>
            )}

            {/* Admin dashboard */}
            {user && user.role === "admin" && (
              <button
                onClick={() => handleViewChange("admin")}
                className={`px-4 py-2 rounded-lg font-medium ${
                  currentView === "admin"
                    ? "bg-blue-600 text-white"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                Admin Dashboard
              </button>
            )}

            {/* Settings menu - now always visible */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setSettingsOpen((open) => !open)}
                className="p-2 rounded-full hover:bg-gray-100 border border-gray-200"
                aria-label="Accessibility & Display Settings"
              >
                <span className="text-lg leading-none text-gray-700">⚙️</span>
              </button>

              {settingsOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white border border-gray-200 rounded-lg shadow-lg z-50 p-4 text-sm">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-semibold text-gray-800">Settings</h3>
                    <button
                      onClick={() => setSettingsOpen(false)}
                      className="text-xs text-gray-500 hover:text-gray-700"
                    >
                      Close
                    </button>
                  </div>

                  {/* Dark mode toggle */}
                  <div className="mb-3">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-gray-700">Dark mode</span>
                      <button
                        type="button"
                        onClick={() => setDarkMode((v) => !v)}
                        className={`w-10 h-5 flex items-center rounded-full transition ${
                          darkMode ? "bg-blue-600" : "bg-gray-300"
                        }`}
                      >
                        <span
                          className={`w-4 h-4 bg-white rounded-full shadow transform transition ${
                            darkMode ? "translate-x-5" : "translate-x-1"
                          }`}
                        />
                      </button>
                    </label>
                  </div>

                  {/* Text size */}
                  <div className="mb-3">
                    <p className="text-gray-700 mb-1">Text size</p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setTextSize("base")}
                        className={`px-2 py-1 rounded border text-xs ${
                          textSize === "base"
                            ? "bg-blue-600 text-white border-blue-600"
                            : "border-gray-300 text-gray-700"
                        }`}
                      >
                        Normal
                      </button>
                      <button
                        type="button"
                        onClick={() => setTextSize("lg")}
                        className={`px-2 py-1 rounded border text-xs ${
                          textSize === "lg"
                            ? "bg-blue-600 text-white border-blue-600"
                            : "border-gray-300 text-gray-700"
                        }`}
                      >
                        Large
                      </button>
                      <button
                        type="button"
                        onClick={() => setTextSize("xl")}
                        className={`px-2 py-1 rounded border text-xs ${
                          textSize === "xl"
                            ? "bg-blue-600 text-white border-blue-600"
                            : "border-gray-300 text-gray-700"
                        }`}
                      >
                        X-Large
                      </button>
                    </div>
                  </div>

                  {/* Image size section removed on purpose */}
                </div>
              )}
            </div>

            {/* User / auth buttons */}
            {user ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-2 bg-gray-100 rounded-lg">
                  <span className="w-6 h-6 flex items-center justify-center rounded-full bg-gray-300 text-xs text-gray-700">
                    {user.name?.[0]?.toUpperCase() || "U"}
                  </span>
                  <span className="text-sm font-medium text-gray-700">
                    {user.name}
                  </span>
                  <span className="text-xs text-gray-500">({user.role})</span>
                </div>
                <button
                  onClick={onLogout}
                  className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium text-sm"
                >
                  <span>⏻</span>
                  <span>Logout</span>
                </button>
              </div>
            ) : (
              <button
                onClick={onLoginClick}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium text-sm"
              >
                <span>🔐</span>
                <span>Login</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;

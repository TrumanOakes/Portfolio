import React, { useState, useEffect } from 'react';
import Navigation from './components/common/Navigation';
import PublicView from './views/PublicView';
import VendorView from './views/VendorView';
import AdminView from './views/AdminView';
import Login from './components/auth/Login';
import authService from './services/authService';
const App = () => {
  const [currentView, setCurrentView] = useState('public');
  const [selectedProject, setSelectedProject] = useState(null);
  const [user, setUser] = useState(null);
  const [showLogin, setShowLogin] = useState(false);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const initAuth = async () => {
      const savedUser = localStorage.getItem('ivvUser');
      const token = localStorage.getItem('jwt');
      if (savedUser && token) {
        try {
          const result = await authService.getCurrentUser();
          if (result.success) {
            setUser(JSON.parse(savedUser));
          } else {
            authService.logout();
          }
        } catch (error) {
          authService.logout();
        }
      }
      setLoading(false);
    };
    initAuth();
  }, []);
  const handleLogin = userData => {
    setUser(userData);
    setShowLogin(false);
    if (userData.role === 'vendor') {
      setCurrentView('vendor');
    } else if (userData.role === 'admin') {
      setCurrentView('admin');
    }
  };
  const handleLogout = () => {
    authService.logout();
    setUser(null);
    setCurrentView('public');
    setSelectedProject(null);
  };
  const handleLoginClick = () => {
    setShowLogin(true);
  };
  const handleCloseLogin = () => {
    setShowLogin(false);
  };
  useEffect(() => {
    if (currentView === 'admin' && (!user || user.role !== 'admin')) {
      setCurrentView('public');
    }
    if (currentView === 'vendor' && (!user || user.role !== 'vendor' && user.role !== 'admin')) {
      setCurrentView('public');
    }
  }, [currentView, user]);
  if (loading) {
    return <div className="min-h-screen bg-gray-50 dark:bg-slate-950 flex items-center justify-center transition-colors duration-200">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-300">Loading...</p>
        </div>
      </div>;
  }
  return <div className="min-h-screen bg-gray-50 dark:bg-slate-950 text-gray-900 dark:text-gray-100 transition-colors duration-200">
      <Navigation currentView={currentView} setCurrentView={setCurrentView} setSelectedProject={setSelectedProject} user={user} onLogout={handleLogout} onLoginClick={handleLoginClick} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentView === 'public' && <PublicView selectedProject={selectedProject} setSelectedProject={setSelectedProject} />}
        {currentView === 'vendor' && user && (user.role === 'vendor' || user.role === 'admin') && <VendorView selectedProject={selectedProject} setSelectedProject={setSelectedProject} user={user} />}
        {currentView === 'admin' && user && user.role === 'admin' && <AdminView selectedProject={selectedProject} setSelectedProject={setSelectedProject} user={user} />}
      </main>

      {showLogin && <Login onLogin={handleLogin} onClose={handleCloseLogin} />}

      <footer className="bg-white dark:bg-slate-900 border-t border-gray-200 dark:border-slate-700 mt-12 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-sm text-gray-600 dark:text-gray-300">
            Enterprise Technology Services (ETS) • Independent Verification &amp; Validation Portal
          </p>
          <p className="text-center text-xs text-gray-500 dark:text-gray-400 mt-2">
            ETS IV&amp;V Portal • Standardized Project Reporting System
          </p>
        </div>
      </footer>
    </div>;
};
export default App;
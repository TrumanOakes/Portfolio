export const calculateRiskRating = (impact, likelihood) => {
  const values = {
    Low: 1,
    Medium: 2,
    High: 3
  };
  return values[impact] + values[likelihood];
};
export const calculateAge = dateFirstRaised => {
  const raised = new Date(dateFirstRaised);
  const today = new Date();
  const diffTime = Math.abs(today - raised);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};
export const getRiskColor = rating => {
  if (rating >= 5) return 'bg-red-100 text-red-800 border-red-300';
  if (rating >= 4) return 'bg-orange-100 text-orange-800 border-orange-300';
  return 'bg-yellow-100 text-yellow-800 border-yellow-300';
};
export const getStatusColor = status => {
  const colors = {
    'Open': 'bg-red-100 text-red-800',
    'In Progress': 'bg-blue-100 text-blue-800',
    'Closed': 'bg-green-100 text-green-800'
  };
  return colors[status] || 'bg-gray-100 text-gray-800';
};
export function unwrap(item) {
  if (!item) return null;
  if (item.attributes) {
    return {
      id: item.id,
      documentId: item.documentId,
      ...item.attributes
    };
  }
  return item;
}
export function normalizeProject(raw) {
  const p = unwrap(raw);
  if (!p) return null;
  let vendor = p.vendor;
  if (vendor && vendor.data) {
    vendor = unwrap(vendor.data);
  }
  return {
    id: p.id,
    slug: p.slug,
    title: p.title,
    description: p.description,
    agency: p.agency,
    status: p.project_status,
    vendor
  };
}
export function normalizeFinancialStatus(raw) {
  const f = unwrap(raw);
  if (!f) return null;
  return {
    originalAwardAmount: f.original_award_amount ?? 0,
    totalPaidToDate: f.total_paid_to_date ?? 0,
    flagOverBudget: !!f.flag_over_budget,
    notes: f.notes || ""
  };
}
export function normalizeScopeStatus(raw) {
  const s = unwrap(raw);
  if (!s) return null;
  const totalScope = s.deliverables_commited ?? 0;
  const completedScope = s.deliverables_completed ?? 0;
  const percentComplete = s.percent_complete ?? (totalScope ? completedScope / totalScope * 100 : 0);
  return {
    totalScope,
    completedScope,
    percentComplete,
    notes: s.notes || ""
  };
}
export function normalizeScheduleStatus(raw) {
  const s = unwrap(raw);
  if (!s) return null;
  return {
    baselineStart: s.baseline_start || null,
    baselineEnd: s.baseline_end || null,
    currentStart: s.current_start || null,
    currentEnd: s.current_end || null,
    varianceDays: s.variance_days ?? 0,
    notes: s.notes || ""
  };
}
export function normalizeIssue(raw) {
  const i = unwrap(raw);
  if (!i) return null;
  const tags = i.tags && i.tags.data ? i.tags.data.map(t => unwrap(t)) : [];
  return {
    id: i.id,
    documentId: i.documentId,
    title: i.title,
    description: i.description,
    impact: i.impact,
    likelihood: i.likelihood,
    riskRating: i.risk_rating,
    status: i.issue_status,
    dateFirstRaised: i.date_first_raised,
    vendorRecommendation: i.Recommendation,
    ageDays: i.age_days,
    tags
  };
}
export function normalizeReport(raw) {
  if (!raw) return null;
  const documentId = raw.documentId || raw.document_id || attrs.documentId;
  if (!documentId) {} else {}
  const attrs = raw.attributes || raw;
  const financial = attrs.financial_status || {};
  const schedule = attrs.schedule_status || {};
  const issues = attrs.issues || [];
  const normalizedIssues = Array.isArray(issues) ? issues.map(issue => {
    const issueData = issue.attributes || issue;
    return {
      id: issue.id,
      documentId: issue.documentId,
      title: issueData.title || 'No title',
      description: issueData.description || 'No description',
      impact: issueData.impact || 'Low',
      likelihood: issueData.likelihood || 'Low',
      riskRating: issueData.risk_rating || 1,
      vendorRecommendation: issueData.Recommendation || 'No recommendation',
      dateFirstRaised: issueData.date_first_raised || new Date().toISOString(),
      status: issueData.issue_status || 'Open',
      ageDays: issueData.age_days || 0
    };
  }) : [];
  const normalized = {
    id: raw.id,
    documentId: raw.documentId,
    reportMonth: attrs.report_month,
    summary: attrs.summary || "",
    locked: attrs.locked || false,
    report_status: attrs.report_status || "Draft",
    publicSlug: attrs.public_slug || "",
    financial: {
      id: financial.id,
      documentId: financial.documentId,
      originalContractAmount: financial.original_award_amount || 0,
      totalPaidOut: financial.total_paid_to_date || 0,
      notes: financial.notes || "",
      flagOverBudget: financial.flag_over_budget || false
    },
    scope: {
      totalScope: schedule.deliverables_commited || 0,
      completedScope: schedule.deliverables_completed || 0,
      percentComplete: schedule.percent_complete || 0,
      notes: schedule.scope_notes || ""
    },
    schedule: {
      id: schedule.id,
      documentId: schedule.documentId,
      baselineStart: schedule.baseline_start || null,
      baselineEnd: schedule.baseline_end || null,
      currentStart: schedule.current_start || null,
      currentEnd: schedule.current_end || null,
      varianceDays: schedule.variance_days || 0,
      notes: schedule.schedule_notes || ""
    },
    issues: normalizedIssues,
    vendor: {
      name: "Vendor Name",
      email: null
    },
    projectId: attrs.project?.id || null
  };
  return normalized;
}
export function deriveScopeStats(report) {
  const scope = report?.scope;
  if (!scope) {
    return {
      totalScope: 0,
      completedScope: 0,
      percentComplete: 0
    };
  }
  return {
    totalScope: scope.totalScope ?? 0,
    completedScope: scope.completedScope ?? 0,
    percentComplete: scope.percentComplete ?? 0
  };
}
export function deriveFinancialStats(report) {
  const f = report?.financial;
  if (!f) {
    return {
      originalAwardAmount: 0,
      totalPaidToDate: 0,
      percentExpended: 0,
      flagOverBudget: false
    };
  }
  const original = f.originalAwardAmount ?? 0;
  const paid = f.totalPaidToDate ?? 0;
  const percentExpended = original ? paid / original * 100 : 0;
  return {
    originalAwardAmount: original,
    totalPaidToDate: paid,
    percentExpended,
    flagOverBudget: f.flagOverBudget
  };
}
export function deriveIssueStats(issues = []) {
  const total = issues.length;
  const open = issues.filter(i => (i.issueStatus || "").toLowerCase() === "open" || (i.issueStatus || "").toLowerCase() === "in progress").length;
  const closed = issues.filter(i => (i.issueStatus || "").toLowerCase() === "closed").length;
  return {
    total,
    open,
    closed
  };
}
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},  // 👈 The new official plugin
    autoprefixer: {},
  },
};
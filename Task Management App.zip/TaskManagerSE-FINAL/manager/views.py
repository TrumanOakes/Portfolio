from django.contrib.auth.decorators import login_required
from django.shortcuts import render

@login_required
def landing(request):
    return render(request, 'manager/completed_landing.html')

@login_required
def list_page(request):
    return render(request, 'manager/list.html')

@login_required
def create_or_edit_page(request):
    task_id = request.GET.get('id')
    return render(request, 'manager/form.html', {'task_id': task_id})

from django.urls import path
from . import views

urlpatterns = [
    path('', views.landing, name='landing'),              # /tasks/
    path('list/', views.list_page, name='task_list'),     # /tasks/list/
    path('new/', views.create_or_edit_page, name='task_create_page'),  # /tasks/new/?id=123
]
